### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/metadata/list_resource_types
### 资源描述
#### 获取资源类型列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                          | 说明               |
| ------- | ------------------------------------------------------------- | ---------------- |
| default | [ResultListResourceTypeInfoVo](#ResultListResourceTypeInfoVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "id" : 0,
    "memberIds" : [ "" ],
    "name" : "",
    "parent" : "",
    "resourceType" : "",
    "system" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListResourceTypeInfoVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | List<[ResourceTypeInfoVo](#ResourceTypeInfoVo)> |     | 数据   |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### ResourceTypeInfoVo
##### 资源类型

| 参数名称         | 参数类型         | 必须  | 参数说明       |
| ------------ | ------------ | --- | ---------- |
| id           | integer      | √   | ID         |
| memberIds    | List<string> | √   | 授权交接失败成员列表 |
| name         | string       | √   | 资源类型名      |
| parent       | string       | √   | 父类资源       |
| resourceType | string       | √   | 资源类型       |
| system       | string       | √   | 所属系统       |

 
