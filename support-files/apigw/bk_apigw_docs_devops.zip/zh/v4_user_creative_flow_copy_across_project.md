### 请求方法/请求路径
#### POST /{apigwType}/v4/projects/{projectId}/creative_flows/copy_across_project
### 资源描述
#### 按分享授权跨空间复制创作流
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| projectId | String | √   | 目标项目ID     |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称 | 参数类型                                                | 必须   |
| ---- | --------------------------------------------------- | ---- |
| 复制请求 | [CreativeFlowCopyRequest](#CreativeFlowCopyRequest) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                          | 说明               |
| ------- | ------------------------------------------------------------- | ---------------- |
| default | [ResultCreativeFlowCopyResult](#ResultCreativeFlowCopyResult) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "conflictPolicy" : "enum",
  "copyDependencies" : false,
  "flowId" : "",
  "shareId" : "",
  "targetEnvHashId" : "",
  "targetPipelineId" : "",
  "targetPipelineName" : "",
  "variableOverrides" : {
    "string" : ""
  }
}
```

### default 返回样例

```Json
{
  "data" : {
    "resolvedSourceVersion" : 0,
    "resolvedSourceVersionNum" : "",
    "skippedReason" : "",
    "status" : "enum",
    "targetPipelineId" : "",
    "targetPipelineName" : "",
    "targetVersion" : 0,
    "targetVersionNum" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### CreativeFlowCopyRequest
##### 创作流跨空间复制请求

| 参数名称               | 参数类型                        | 必须  | 参数说明                                 |
| ------------------ | --------------------------- | --- | ------------------------------------ |
| conflictPolicy     | ENUM(SKIP, OVERWRITE, FAIL) | √   | 冲突策略：SKIP / OVERWRITE / FAIL，默认 SKIP |
| copyDependencies   | boolean                     | √   | 是否迁移依赖资源，本迭代仅接受false                 |
| flowId             | string                      | √   | 创作流条目ID                              |
| shareId            | string                      | √   | 分享ID                                 |
| targetEnvHashId    | string                      | √   | 目标环境HashId，创作流必填                     |
| targetPipelineId   | string                      |     | OVERWRITE时必填，且必须是本授权已登记的副本           |
| targetPipelineName | string                      |     | 目标创作流名称，缺省用授权中的源名称                   |
| variableOverrides  | Map<String, string>         |     | 变量覆盖，key为变量名                         |

#### ResultCreativeFlowCopyResult
##### 数据返回包装模型

| 参数名称    | 参数类型                                              | 必须  | 参数说明 |
| ------- | ------------------------------------------------- | --- | ---- |
| data    | [CreativeFlowCopyResult](#CreativeFlowCopyResult) |     |      |
| message | string                                            |     | 错误信息 |
| status  | integer                                           | √   | 状态码  |

#### CreativeFlowCopyResult
##### 创作流跨空间复制结果

| 参数名称                     | 参数类型                                | 必须  | 参数说明                                 |
| ------------------------ | ----------------------------------- | --- | ------------------------------------ |
| resolvedSourceVersion    | integer                             |     | 实际复制的源版本号（内部整型）                      |
| resolvedSourceVersionNum | string                              |     | 实际复制的源发布版本号，形如 V208                  |
| skippedReason            | string                              |     | SKIPPED 时的原因                         |
| status                   | ENUM(CREATED, OVERWRITTEN, SKIPPED) | √   | 复制状态：CREATED / OVERWRITTEN / SKIPPED |
| targetPipelineId         | string                              |     | 目标流水线ID                              |
| targetPipelineName       | string                              |     | 目标创作流名称                              |
| targetVersion            | integer                             |     | 目标版本号（内部整型）                          |
| targetVersionNum         | string                              |     | 目标发布版本号，形如 V1                        |

 
