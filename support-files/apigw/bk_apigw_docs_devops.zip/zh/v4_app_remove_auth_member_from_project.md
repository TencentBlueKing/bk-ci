### 请求方法/请求路径
#### PUT /{apigwType}/v4/auth/project/{projectId}/member_manage/members/remove_from_project
### 资源描述
#### 将用户移出项目
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称       | 参数类型                                                          | 必须   |
| ---------- | ------------------------------------------------------------- | ---- |
| 将成员移出项目请求体 | [AiRemoveMemberFromProjectReq](#AiRemoveMemberFromProjectReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                          | 说明               |
| ------- | ------------------------------------------------------------- | ---------------- |
| default | [ResultListResourceMemberInfo](#ResultListResourceMemberInfo) | default response |

### Curl 请求样例

```Json
curl -X PUT '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### PUT 请求样例

```Json
{
  "handoverToMemberId" : "",
  "targetMemberId" : ""
}
```

### default 返回样例

```Json
{
  "data" : [ {
    "departed" : false,
    "id" : "",
    "name" : "",
    "type" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### AiRemoveMemberFromProjectReq
##### 移出项目成员请求体

| 参数名称               | 参数类型   | 必须  | 参数说明     |
| ------------------ | ------ | --- | -------- |
| handoverToMemberId | string |     | 权限交接人ID  |
| targetMemberId     | string | √   | 要移除的成员ID |

#### ResultListResourceMemberInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | List<[ResourceMemberInfo](#ResourceMemberInfo)> |     | 数据   |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### ResourceMemberInfo
##### 成员信息

| 参数名称     | 参数类型    | 必须  | 参数说明 |
| -------- | ------- | --- | ---- |
| departed | boolean |     | 是否离职 |
| id       | string  | √   | 成员id |
| name     | string  |     | 成员名称 |
| type     | string  | √   | 成员类型 |

 
