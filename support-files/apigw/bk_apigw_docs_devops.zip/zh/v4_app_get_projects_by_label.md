### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/project/get_projects_by_label
### 资源描述
#### 根据项目标签查询项目ID列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称     | 参数类型               | 必须  | 参数说明               |
| -------- | ------------------ | --- | ------------------ |
| label    | ENUM(COMMON_IMATE) | √   | 项目标签               |
| page     | integer            |     | 页码，从1开始            |
| pageSize | integer            |     | 每页条数，默认100，最大10000 |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                  | 说明               |
| ------- | ------------------------------------- | ---------------- |
| default | [ResultPageString](#ResultPageString) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?label={label}&page={page}&pageSize={pageSize}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "code" : 0,
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ "" ],
    "totalPages" : 0
  },
  "message" : "",
  "requestId" : "",
  "request_id" : "",
  "result" : false
}
```

### 相关模型数据
#### ResultPageString
##### 数据返回包装模型

| 参数名称       | 参数类型                      | 必须  | 参数说明 |
| ---------- | ------------------------- | --- | ---- |
| code       | integer                   | √   | 状态码  |
| data       | [PageString](#PageString) |     |      |
| message    | string                    |     | 错误信息 |
| requestId  | string                    |     | 请求ID |
| request_id | string                    |     |      |
| result     | boolean                   |     | 请求结果 |

#### PageString
##### 分页数据包装模型

| 参数名称       | 参数类型         | 必须  | 参数说明  |
| ---------- | ------------ | --- | ----- |
| count      | integer      | √   | 总记录行数 |
| page       | integer      | √   | 第几页   |
| pageSize   | integer      | √   | 每页多少条 |
| records    | List<string> | √   | 数据    |
| totalPages | integer      | √   | 总共多少页 |

 
