### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_insight/resources/{resourceType}/{resourceCode}/permissions_matrix
### 资源描述
#### 资源权限矩阵
### 输入参数说明
#### Path参数

| 参数名称         | 参数类型   | 必须  | 参数说明                               |
| ------------ | ------ | --- | ---------------------------------- |
| apigwType    | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId    | String | √   | 项目ID(项目英文名)                        |
| resourceCode | String | √   | 资源Code                             |
| resourceType | String | √   | 资源类型                               |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                    | 说明               |
| ------- | ----------------------------------------------------------------------- | ---------------- |
| default | [ResultResourcePermissionsMatrixVO](#ResultResourcePermissionsMatrixVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "groups" : [ {
      "groupName" : "",
      "managementLevel" : "",
      "managementScope" : "",
      "orgCount" : 0,
      "orgs" : [ "" ],
      "permissions" : [ "" ],
      "relationId" : 0,
      "userCount" : 0,
      "users" : [ "" ]
    } ],
    "projectId" : "",
    "resourceName" : "",
    "resourceType" : "",
    "totalGroupCount" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultResourcePermissionsMatrixVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                                        | 必须  | 参数说明 |
| ------- | ----------------------------------------------------------- | --- | ---- |
| data    | [ResourcePermissionsMatrixVO](#ResourcePermissionsMatrixVO) |     |      |
| message | string                                                      |     | 错误信息 |
| status  | integer                                                     | √   | 状态码  |

#### ResourcePermissionsMatrixVO
##### 资源权限矩阵

| 参数名称            | 参数类型                                                  | 必须  | 参数说明    |
| --------------- | ----------------------------------------------------- | --- | ------- |
| groups          | List<[ResourceGroupMatrixVO](#ResourceGroupMatrixVO)> | √   | 关联用户组列表 |
| projectId       | string                                                | √   | 项目ID    |
| resourceName    | string                                                | √   | 资源名称    |
| resourceType    | string                                                | √   | 资源类型    |
| totalGroupCount | integer                                               | √   | 关联用户组总数 |

#### ResourceGroupMatrixVO
##### 资源权限矩阵中的用户组信息

| 参数名称            | 参数类型         | 必须  | 参数说明              |
| --------------- | ------------ | --- | ----------------- |
| groupName       | string       | √   | 用户组名称             |
| managementLevel | string       | √   | 管理层级（项目/流水线组/流水线） |
| managementScope | string       | √   | 管理范围              |
| orgCount        | integer      | √   | 关联组织数量            |
| orgs            | List<string> | √   | 关联组织列表            |
| permissions     | List<string> | √   | 拥有的权限列表           |
| relationId      | integer      | √   | 用户组关联ID           |
| userCount       | integer      | √   | 成员人数              |
| users           | List<string> | √   | 成员列表              |

 
