### 请求方法/请求路径
#### GET /{apigwType}/v4/creative_stream/stage_review_content
### 资源描述
#### CDS 预定义接口：拉取创作流 Stage 审核卡片
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称   | 参数类型   | 必须  | 参数说明      |
| ------ | ------ | --- | --------- |
| taskId | String | √   | 审批 taskId |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                              | 说明               |
| ------- | --------------------------------------------------------------------------------- | ---------------- |
| default | [ResultCreativeStreamStageReviewContent](#ResultCreativeStreamStageReviewContent) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?taskId={taskId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "approvalContent" : "",
    "expireAt" : "",
    "title" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultCreativeStreamStageReviewContent
##### 数据返回包装模型

| 参数名称    | 参数类型                                                                  | 必须  | 参数说明 |
| ------- | --------------------------------------------------------------------- | --- | ---- |
| data    | [CreativeStreamStageReviewContent](#CreativeStreamStageReviewContent) |     |      |
| message | string                                                                |     | 错误信息 |
| status  | integer                                                               | √   | 状态码  |

#### CreativeStreamStageReviewContent
##### 创作流 Stage 审核卡片内容（CDS 预定义接口）

| 参数名称            | 参数类型   | 必须  | 参数说明           |
| --------------- | ------ | --- | -------------- |
| approvalContent | string | √   | 审批正文（Markdown） |
| expireAt        | string |     | 过期时间（ISO-8601） |
| title           | string | √   | 审批标题           |

 
