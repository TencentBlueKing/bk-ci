### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_insight/diagnose
### 资源描述
#### 权限诊断:分析成员为什么没有某权限
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称         | 参数类型   | 必须  | 参数说明                     |
| ------------ | ------ | --- | ------------------------ |
| action       | String | √   | 权限动作(如 pipeline_execute) |
| memberId     | String | √   | 目标成员ID                   |
| resourceCode | String | √   | 资源Code                   |
| resourceType | String | √   | 资源类型                     |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                      | 说明               |
| ------- | --------------------------------------------------------- | ---------------- |
| default | [ResultPermissionDiagnoseVO](#ResultPermissionDiagnoseVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?action={action}&memberId={memberId}&resourceCode={resourceCode}&resourceType={resourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "action" : "",
    "actionName" : "",
    "applicableGroups" : [ {
      "groupId" : 0,
      "groupName" : "",
      "managementLevel" : "",
      "managementScope" : "",
      "permissions" : [ "" ],
      "tags" : [ {
        "text" : "",
        "type" : "enum"
      } ]
    } ],
    "groupManagers" : [ "" ],
    "hasPermission" : false,
    "missingReason" : "",
    "resourceCode" : "",
    "resourceName" : "",
    "resourceType" : "",
    "suggestion" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPermissionDiagnoseVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                          | 必须  | 参数说明 |
| ------- | --------------------------------------------- | --- | ---- |
| data    | [PermissionDiagnoseVO](#PermissionDiagnoseVO) |     |      |
| message | string                                        |     | 错误信息 |
| status  | integer                                       | √   | 状态码  |

#### PermissionDiagnoseVO
##### 权限诊断结果

| 参数名称             | 参数类型                                          | 必须  | 参数说明          |
| ---------------- | --------------------------------------------- | --- | ------------- |
| action           | string                                        | √   | 操作类型          |
| actionName       | string                                        | √   | 操作名称          |
| applicableGroups | List<[ApplicableGroupVO](#ApplicableGroupVO)> | √   | 可申请的用户组列表     |
| groupManagers    | List<string>                                  | √   | 用户组管理员（可联系申请） |
| hasPermission    | boolean                                       | √   | 是否有权限         |
| missingReason    | string                                        |     | 缺失原因          |
| resourceCode     | string                                        | √   | 资源Code        |
| resourceName     | string                                        | √   | 资源名称          |
| resourceType     | string                                        | √   | 资源类型          |
| suggestion       | string                                        |     | 建议操作          |

#### ApplicableGroupVO
##### 可申请的用户组

| 参数名称            | 参数类型                                      | 必须  | 参数说明    |
| --------------- | ----------------------------------------- | --- | ------- |
| groupId         | integer                                   | √   | 用户组ID   |
| groupName       | string                                    | √   | 用户组名称   |
| managementLevel | string                                    | √   | 管理层级    |
| managementScope | string                                    | √   | 管理范围    |
| permissions     | List<string>                              | √   | 包含的权限列表 |
| tags            | List<[PermissionTagVO](#PermissionTagVO)> | √   | 推荐标签    |

#### PermissionTagVO
##### 权限推荐/警告标签

| 参数名称 | 参数类型                           | 必须  | 参数说明 |
| ---- | ------------------------------ | --- | ---- |
| text | string                         | √   | 标签文案 |
| type | ENUM(RECOMMEND, WARNING, INFO) | √   | 标签类型 |

 
