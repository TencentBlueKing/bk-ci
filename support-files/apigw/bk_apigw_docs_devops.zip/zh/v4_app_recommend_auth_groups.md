### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/member_manage/recommend_groups
### 资源描述
#### 智能推荐用户组
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称                       | 参数类型                                    | 必须   |
| -------------------------- | --------------------------------------- | ---- |
| 用户组推荐请求体(含目标成员、资源信息和期望动作等) | [GroupRecommendReq](#GroupRecommendReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                        | 说明               |
| ------- | ----------------------------------------------------------- | ---------------- |
| default | [ResultGroupRecommendationVO](#ResultGroupRecommendationVO) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "action" : "",
  "resourceCode" : "",
  "resourceType" : "",
  "targetUserId" : ""
}
```

### default 返回样例

```Json
{
  "data" : {
    "candidateGroups" : [ {
      "alreadyMember" : false,
      "groupName" : "",
      "managementLevel" : "",
      "managementScope" : "",
      "permissions" : [ "" ],
      "relationId" : 0,
      "tags" : [ {
        "text" : "",
        "type" : "enum"
      } ]
    } ],
    "recommendation" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### GroupRecommendReq
##### 用户组推荐请求体

| 参数名称         | 参数类型   | 必须  | 参数说明   |
| ------------ | ------ | --- | ------ |
| action       | string | √   | 目标操作权限 |
| resourceCode | string | √   | 资源Code |
| resourceType | string | √   | 资源类型   |
| targetUserId | string | √   | 目标用户ID |

#### ResultGroupRecommendationVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | [GroupRecommendationVO](#GroupRecommendationVO) |     |      |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### GroupRecommendationVO
##### 用户组推荐结果

| 参数名称            | 参数类型                                        | 必须  | 参数说明    |
| --------------- | ------------------------------------------- | --- | ------- |
| candidateGroups | List<[CandidateGroupVO](#CandidateGroupVO)> | √   | 候选用户组列表 |
| recommendation  | string                                      | √   | 推荐建议    |

#### CandidateGroupVO
##### 推荐候选用户组

| 参数名称            | 参数类型                                      | 必须  | 参数说明       |
| --------------- | ----------------------------------------- | --- | ---------- |
| alreadyMember   | boolean                                   | √   | 目标用户是否已是成员 |
| groupName       | string                                    | √   | 用户组名称      |
| managementLevel | string                                    | √   | 管理层级       |
| managementScope | string                                    | √   | 管理范围       |
| permissions     | List<string>                              | √   | 拥有的权限列表    |
| relationId      | integer                                   | √   | 用户组关联ID    |
| tags            | List<[PermissionTagVO](#PermissionTagVO)> | √   | 推荐/警告标签    |

#### PermissionTagVO
##### 权限推荐/警告标签

| 参数名称 | 参数类型                           | 必须  | 参数说明 |
| ---- | ------------------------------ | --- | ---- |
| text | string                         | √   | 标签文案 |
| type | ENUM(RECOMMEND, WARNING, INFO) | √   | 标签类型 |

 
