### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/creative_flows/copy_traces
### 资源描述
#### 查询复制溯源记录
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| projectId | String | √   | 目标项目ID     |

#### Query参数

| 参数名称             | 参数类型   | 必须  | 参数说明     |
| ---------------- | ------ | --- | -------- |
| flowId           | String |     | 分享条目ID   |
| shareId          | String |     | 分享命名空间ID |
| targetPipelineId | String |     | 目标流水线ID  |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                    | 说明               |
| ------- | ----------------------------------------------------------------------- | ---------------- |
| default | [ResultListCreativeFlowCopyTraceVo](#ResultListCreativeFlowCopyTraceVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?flowId={flowId}&shareId={shareId}&targetPipelineId={targetPipelineId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "copyAction" : "enum",
    "createTime" : 0,
    "flowId" : "",
    "id" : 0,
    "operator" : "",
    "scene" : "enum",
    "shareId" : "",
    "shareMode" : "enum",
    "sourcePipelineId" : "",
    "sourceProjectId" : "",
    "sourceVersion" : 0,
    "sourceVersionNum" : "",
    "talentCode" : "",
    "targetEnvHashId" : "",
    "targetPipelineId" : "",
    "targetPipelineName" : "",
    "targetProjectId" : "",
    "targetVersion" : 0,
    "targetVersionNum" : "",
    "variableOverrides" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListCreativeFlowCopyTraceVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                      | 必须  | 参数说明 |
| ------- | --------------------------------------------------------- | --- | ---- |
| data    | List<[CreativeFlowCopyTraceVo](#CreativeFlowCopyTraceVo)> |     | 数据   |
| message | string                                                    |     | 错误信息 |
| status  | integer                                                   | √   | 状态码  |

#### CreativeFlowCopyTraceVo
##### 创作流复制溯源记录

| 参数名称               | 参数类型                                | 必须  | 参数说明 |
| ------------------ | ----------------------------------- | --- | ---- |
| copyAction         | ENUM(CREATED, OVERWRITTEN, SKIPPED) | √   |      |
| createTime         | integer                             | √   |      |
| flowId             | string                              | √   |      |
| id                 | integer                             | √   |      |
| operator           | string                              | √   |      |
| scene              | ENUM(TALENT_FOLLOW)                 | √   |      |
| shareId            | string                              | √   |      |
| shareMode          | ENUM(COPY)                          | √   |      |
| sourcePipelineId   | string                              | √   |      |
| sourceProjectId    | string                              | √   |      |
| sourceVersion      | integer                             | √   |      |
| sourceVersionNum   | string                              |     |      |
| talentCode         | string                              |     |      |
| targetEnvHashId    | string                              |     |      |
| targetPipelineId   | string                              | √   |      |
| targetPipelineName | string                              | √   |      |
| targetProjectId    | string                              | √   |      |
| targetVersion      | integer                             | √   |      |
| targetVersionNum   | string                              |     |      |
| variableOverrides  | string                              |     |      |

 
