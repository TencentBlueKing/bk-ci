### 请求方法/请求路径
#### PUT /{apigwType}/v4/auth/project/{projectId}/member_manage/members/exits_project
### 资源描述
#### 用户主动退出项目
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称        | 参数类型                                                | 必须   |
| ----------- | --------------------------------------------------- | ---- |
| 用户主动退出项目请求体 | [AiMemberExitsProjectReq](#AiMemberExitsProjectReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                          | 说明               |
| ------- | ----------------------------- | ---------------- |
| default | [ResultString](#ResultString) | default response |

### Curl 请求样例

```Json
curl -X PUT '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### PUT 请求样例

```Json
{
  "handoverToMemberId" : ""
}
```

### default 返回样例

```Json
{
  "data" : "",
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### AiMemberExitsProjectReq
##### AI-用户主动退出项目请求体

| 参数名称               | 参数类型   | 必须  | 参数说明                       |
| ------------------ | ------ | --- | -------------------------- |
| handoverToMemberId | string |     | 交接人用户ID（可选，检查结果不能直接退出时需传入） |

#### ResultString
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | string  |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
