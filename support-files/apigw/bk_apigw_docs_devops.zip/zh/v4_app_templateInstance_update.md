### 请求方法/请求路径
#### PUT /{apigwType}/v4/projects/{projectId}/templates/templateInstances
### 资源描述
#### 批量更新流水线模板实例
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称                | 参数类型    | 必须  | 参数说明                             |
| ------------------- | ------- | --- | -------------------------------- |
| templateId          | String  | √   | 模板ID                             |
| useTemplateSettings | boolean |     | 是否应用模板设置                         |
| version             | integer | √   | 版本名（可通过v3_app_template_list接口获取） |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称 | 参数类型                                                    | 必须   |
| ---- | ------------------------------------------------------- | ---- |
| 模板实例 | List<[TemplateInstanceUpdate](#TemplateInstanceUpdate)> | true |

#### 响应参数

| HTTP代码  | 参数类型                                          | 说明               |
| ------- | --------------------------------------------- | ---------------- |
| default | [TemplateOperationRet](#TemplateOperationRet) | default response |

### Curl 请求样例

```Json
curl -X PUT '[请替换为上方API地址栏请求地址]?templateId={templateId}&useTemplateSettings={useTemplateSettings}&version={version}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### PUT 请求样例

```Json
[ {
  "buildNo" : {
    "buildNo" : 0
  },
  "param" : [ {
    "asInstanceInput" : false,
    "cascadeProps" : {
      "children" : "#/components/schemas/BuildCascadeProps",
      "id" : "",
      "options" : [ {
        "key" : "",
        "value" : ""
      } ],
      "replaceKey" : "",
      "searchUrl" : ""
    },
    "category" : "",
    "constant" : false,
    "containerType" : {
      "buildType" : "enum",
      "os" : "enum"
    },
    "defaultValue" : "Any 任意类型，参照实际请求或返回",
    "desc" : "",
    "displayCondition" : {
      "string" : ""
    },
    "enableVersionControl" : false,
    "fields" : [ "#/components/schemas/BuildFormProperty" ],
    "glob" : "",
    "id" : "",
    "label" : "",
    "latestRandomStringInPath" : "",
    "name" : "",
    "options" : [ {
      "key" : "",
      "value" : ""
    } ],
    "payload" : "Any 任意类型，参照实际请求或返回",
    "placeholder" : "",
    "properties" : {
      "string" : ""
    },
    "propertyType" : "",
    "randomStringInPath" : "",
    "readOnly" : false,
    "relativePath" : "",
    "removeFlag" : false,
    "replaceKey" : "",
    "repoHashId" : "",
    "required" : false,
    "scmType" : "enum",
    "searchUrl" : "",
    "sensitive" : false,
    "type" : "enum",
    "value" : "Any 任意类型，参照实际请求或返回",
    "valueNotEmpty" : false,
    "varGroupName" : "",
    "varGroupVersion" : 0
  } ],
  "pipelineId" : "",
  "pipelineName" : "",
  "resetBuildNo" : false
} ]
```

### default 返回样例

```Json
{
  "data" : {
    "failureMessages" : {
      "string" : ""
    },
    "failurePipelines" : [ "" ],
    "successPipelines" : [ "" ],
    "successPipelinesId" : [ "" ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### TemplateInstanceUpdate
##### 

| 参数名称         | 参数类型                                          | 必须  | 参数说明                                       |
| ------------ | --------------------------------------------- | --- | ------------------------------------------ |
| buildNo      | [BuildNo](#BuildNo)                           |     |                                            |
| param        | List<[BuildFormProperty](#BuildFormProperty)> |     | 流水线变量列表, 建议先通过v4_app_template_get获取，再按需修改。 |
| pipelineId   | string                                        |     | 流水线id                                      |
| pipelineName | string                                        |     | 流水线那名称                                     |
| resetBuildNo | boolean                                       |     | 重置实例推荐版本为基准值                               |

#### BuildNo
##### 构建版本号

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| buildNo | integer |     | 初始值  |

#### BuildFormProperty
##### 构建模型-表单元素属性

| 参数名称                     | 参数类型                                                                                                                                                                                                       | 必须  | 参数说明                                                  |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --- | ----------------------------------------------------- |
| asInstanceInput          | boolean                                                                                                                                                                                                    |     | 在新增实例、以及新增变量时作用，控制实例化页面「实例入参」按钮, 当required:true时,值才生效 |
| cascadeProps             | [BuildCascadeProps](#BuildCascadeProps)                                                                                                                                                                    |     |                                                       |
| category                 | string                                                                                                                                                                                                     |     | 分组信息                                                  |
| constant                 | boolean                                                                                                                                                                                                    |     | 是否为常量                                                 |
| containerType            | [BuildContainerType](#BuildContainerType)                                                                                                                                                                  |     |                                                       |
| defaultValue             | Any                                                                                                                                                                                                        | √   | 默认值                                                   |
| desc                     | string                                                                                                                                                                                                     |     | 描述                                                    |
| displayCondition         | Map<String, string>                                                                                                                                                                                        |     | 展示条件                                                  |
| enableVersionControl     | boolean                                                                                                                                                                                                    |     | 开启文件版本管理                                              |
| fields                   | List<[BuildFormProperty](#BuildFormProperty)>                                                                                                                                                              |     | 复杂参数列表[仅type==CUSTOM_PARAM有效]                         |
| glob                     | string                                                                                                                                                                                                     |     | 自定义仓库通配符                                              |
| id                       | string                                                                                                                                                                                                     | √   | 元素ID-标识符                                              |
| label                    | string                                                                                                                                                                                                     |     | 元素标签                                                  |
| latestRandomStringInPath | string                                                                                                                                                                                                     |     | 最新的目录随机字符串                                            |
| name                     | string                                                                                                                                                                                                     |     | 元素名称                                                  |
| options                  | List<[BuildFormValue](#BuildFormValue)>                                                                                                                                                                    |     | 下拉框列表                                                 |
| payload                  | Any                                                                                                                                                                                                        |     | 页面所需内容，后台仅保存，不做处理                                     |
| placeholder              | string                                                                                                                                                                                                     |     | 元素placeholder                                         |
| properties               | Map<String, string>                                                                                                                                                                                        |     | 文件元数据                                                 |
| propertyType             | string                                                                                                                                                                                                     |     | 元素模块                                                  |
| randomStringInPath       | string                                                                                                                                                                                                     |     | 目录随机字符串                                               |
| readOnly                 | boolean                                                                                                                                                                                                    |     | 是否只读                                                  |
| relativePath             | string                                                                                                                                                                                                     |     | relativePath                                          |
| removeFlag               | boolean                                                                                                                                                                                                    | √   | 是否已移除                                                 |
| replaceKey               | string                                                                                                                                                                                                     |     | 替换搜索url中的搜素关键字                                        |
| repoHashId               | string                                                                                                                                                                                                     |     | repoHashId                                            |
| required                 | boolean                                                                                                                                                                                                    | √   | 是否必须（新前端的入参标识）                                        |
| scmType                  | ENUM(CODE_SVN, CODE_GIT, CODE_GITLAB, GITHUB, CODE_TGIT, CODE_P4, SCM_GIT, SCM_SVN, SCM_P4)                                                                                                                |     | 代码库类型下拉                                               |
| searchUrl                | string                                                                                                                                                                                                     |     | 搜索url, 当是下拉框选项时，列表值从url获取不再从option获取                  |
| sensitive                | boolean                                                                                                                                                                                                    |     | 是否为敏感字段                                               |
| type                     | ENUM(string, textarea, enum, date, long, boolean, svn_tag, git_ref, repo_ref, multiple, code_lib, container_type, artifactory, sub_pipeline, custom_file, password, do not storage in database, form_list) | √   | 元素类型                                                  |
| value                    | Any                                                                                                                                                                                                        |     | 上次构建的取值                                               |
| valueNotEmpty            | boolean                                                                                                                                                                                                    |     | 参数值是否必填                                               |
| varGroupName             | string                                                                                                                                                                                                     |     | 所属公共变量组名称                                             |
| varGroupVersion          | integer                                                                                                                                                                                                    |     | 所属公共变量组版本                                             |

#### BuildCascadeProps
##### 构建模型-表单元素属性

| 参数名称       | 参数类型                                    | 必须  | 参数说明 |
| ---------- | --------------------------------------- | --- | ---- |
| children   | [BuildCascadeProps](#BuildCascadeProps) |     |      |
| id         | string                                  | √   |      |
| options    | List<[BuildFormValue](#BuildFormValue)> | √   |      |
| replaceKey | string                                  |     |      |
| searchUrl  | string                                  |     |      |

#### BuildFormValue
##### 构建模型-下拉框表单元素值

| 参数名称  | 参数类型   | 必须  | 参数说明      |
| ----- | ------ | --- | --------- |
| key   | string | √   | 元素值ID-标识符 |
| value | string | √   | 元素值名称-显示用 |

#### BuildContainerType
##### 构建机类型下拉

| 参数名称      | 参数类型                                                                                                                                                                                                         | 必须  | 参数说明 |
| --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --- | ---- |
| buildType | ENUM(ESXi, MACOS, WINDOWS, KUBERNETES, PUBLIC_DEVCLOUD, PUBLIC_BCS, THIRD_PARTY_AGENT_ID, THIRD_PARTY_AGENT_ENV, CREATE_AGENT_ID, THIRD_PARTY_PCG, THIRD_PARTY_DEVCLOUD, GIT_CI, DOCKER, STREAM, AGENT_LESS) |     |      |
| os        | ENUM(MACOS, WINDOWS, LINUX)                                                                                                                                                                                  |     |      |

#### TemplateOperationRet
##### 返回模型

| 参数名称    | 参数类型                                                  | 必须  | 参数说明       |
| ------- | ----------------------------------------------------- | --- | ---------- |
| data    | [TemplateOperationMessage](#TemplateOperationMessage) | √   |            |
| message | string                                                | √   | message 信息 |
| status  | integer                                               | √   | 状态码        |

#### TemplateOperationMessage
##### data 信息

| 参数名称               | 参数类型                | 必须  | 参数说明     |
| ------------------ | ------------------- | --- | -------- |
| failureMessages    | Map<String, string> |     | 失败信息     |
| failurePipelines   | List<string>        |     | 失败的流水线   |
| successPipelines   | List<string>        |     | 成功的流水线   |
| successPipelinesId | List<string>        |     | 成功的流水线id |

 
