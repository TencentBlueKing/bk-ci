### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/pipelines/pipeline_count
### 资源描述
#### 获取列表页列表相关的数目
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                        | 说明               |
| ------- | ------------------------------------------- | ---------------- |
| default | [ResultPipelineCount](#ResultPipelineCount) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "myFavoriteCount" : 0,
    "myPipelineCount" : 0,
    "recentUseCount" : 0,
    "recycleCount" : 0,
    "totalCount" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPipelineCount
##### 数据返回包装模型

| 参数名称    | 参数类型                            | 必须  | 参数说明 |
| ------- | ------------------------------- | --- | ---- |
| data    | [PipelineCount](#PipelineCount) |     |      |
| message | string                          |     | 错误信息 |
| status  | integer                         | √   | 状态码  |

#### PipelineCount
##### 流水线数量相关

| 参数名称            | 参数类型    | 必须  | 参数说明        |
| --------------- | ------- | --- | ----------- |
| myFavoriteCount | integer | √   | 我的收藏个数      |
| myPipelineCount | integer | √   | 我的流水线的个数    |
| recentUseCount  | integer | √   | 最近使用的流水线的个数 |
| recycleCount    | integer | √   | 回收站流水线的个数   |
| totalCount      | integer | √   | 全部流水线个数     |

 
