### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/get_project_group_and_users
### 资源描述
#### 获取项目组成员
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| projectId | String | √   | projectId  |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                  | 说明               |
| ------- | --------------------------------------------------------------------- | ---------------- |
| default | [ResultListBkAuthGroupAndUserList](#ResultListBkAuthGroupAndUserList) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "applyDisable" : false,
    "apply_disable" : false,
    "deptInfoList" : [ {
      "created_at" : 0,
      "expired_at" : 0,
      "id" : "",
      "name" : "",
      "type" : ""
    } ],
    "dept_info_list" : [ {
      "created_at" : 0,
      "expired_at" : 0,
      "id" : "",
      "name" : "",
      "type" : ""
    } ],
    "displayName" : "",
    "display_name" : "",
    "roleId" : 0,
    "roleName" : "",
    "role_id" : 0,
    "role_name" : "",
    "type" : "",
    "userIdList" : [ "" ],
    "user_id_list" : [ "" ]
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListBkAuthGroupAndUserList
##### 数据返回包装模型

| 参数名称    | 参数类型                                                    | 必须  | 参数说明 |
| ------- | ------------------------------------------------------- | --- | ---- |
| data    | List<[BkAuthGroupAndUserList](#BkAuthGroupAndUserList)> |     | 数据   |
| message | string                                                  |     | 错误信息 |
| status  | integer                                                 | √   | 状态码  |

#### BkAuthGroupAndUserList
##### 数据

| 参数名称           | 参数类型                                              | 必须  | 参数说明                  |
| -------------- | ------------------------------------------------- | --- | --------------------- |
| applyDisable   | boolean                                           |     | 是否禁止申请，当字段为true时，禁止申请 |
| apply_disable  | boolean                                           |     |                       |
| deptInfoList   | List<[RoleGroupMemberInfo](#RoleGroupMemberInfo)> |     | 部门列表                  |
| dept_info_list | List<[RoleGroupMemberInfo](#RoleGroupMemberInfo)> |     |                       |
| displayName    | string                                            |     | 组名称                   |
| display_name   | string                                            |     |                       |
| roleId         | integer                                           |     | 用户组Id                 |
| roleName       | string                                            |     |                       |
| role_id        | integer                                           |     |                       |
| role_name      | string                                            |     |                       |
| type           | string                                            |     |                       |
| userIdList     | List<string>                                      |     | 用户列表                  |
| user_id_list   | List<string>                                      |     |                       |

#### RoleGroupMemberInfo
##### 部门列表

| 参数名称       | 参数类型    | 必须  | 参数说明 |
| ---------- | ------- | --- | ---- |
| created_at | integer |     |      |
| expired_at | integer |     |      |
| id         | string  |     |      |
| name       | string  |     |      |
| type       | string  |     |      |

 
