### 请求方法/请求路径
#### GET /{apigwType}/v4/environment/projects/{projectId}/envs/{envHashId}/nodes_list
### 资源描述
#### 获取环境的节点列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| envHashId | String | √   | 环境 hashId   |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称        | 参数类型                                                                                                                                                                                                                 | 必须  | 参数说明     |
| ----------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --- | -------- |
| createdUser | String                                                                                                                                                                                                               |     | 创建人      |
| displayName | String                                                                                                                                                                                                               |     | 别名       |
| nodeIp      | String                                                                                                                                                                                                               |     | IP       |
| nodeStatus  | ENUM(NORMAL, ABNORMAL, NOT_INSTALLED, DELETED, LOST, CREATING, RUNNING, STARTING, STOPPING, STOPPED, RESTARTING, DELETING, BUILDING_IMAGE, BUILD_IMAGE_SUCCESS, BUILD_IMAGE_FAILED, NOT_IN_CC, NOT_IN_CMDB, UNKNOWN) |     | Agent 状态 |
| page        | integer                                                                                                                                                                                                              |     | 第几页      |
| pageSize    | integer                                                                                                                                                                                                              |     | 每页多少条    |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                              | 说明               |
| ------- | ------------------------------------------------- | ---------------- |
| default | [ResultPageNodeBaseInfo](#ResultPageNodeBaseInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?createdUser={createdUser}&displayName={displayName}&nodeIp={nodeIp}&nodeStatus={nodeStatus}&page={page}&pageSize={pageSize}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "agentHashId" : "",
      "agentId" : 0,
      "agentStatus" : false,
      "bakOperator" : "",
      "bizId" : 0,
      "createWorkspaceId" : "",
      "createdUser" : "",
      "displayName" : "",
      "envEnableNode" : false,
      "gateway" : "",
      "ip" : "",
      "lastModifyTime" : 0,
      "name" : "",
      "nodeHashId" : "",
      "nodeId" : "",
      "nodeName" : "",
      "nodeStatus" : "",
      "nodeType" : "",
      "operator" : "",
      "operatorStatus" : "",
      "osName" : "",
      "size" : ""
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPageNodeBaseInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                  | 必须  | 参数说明 |
| ------- | ------------------------------------- | --- | ---- |
| data    | [PageNodeBaseInfo](#PageNodeBaseInfo) |     |      |
| message | string                                |     | 错误信息 |
| status  | integer                               | √   | 状态码  |

#### PageNodeBaseInfo
##### 分页数据包装模型

| 参数名称       | 参数类型                                | 必须  | 参数说明  |
| ---------- | ----------------------------------- | --- | ----- |
| count      | integer                             | √   | 总记录行数 |
| page       | integer                             | √   | 第几页   |
| pageSize   | integer                             | √   | 每页多少条 |
| records    | List<[NodeBaseInfo](#NodeBaseInfo)> | √   | 数据    |
| totalPages | integer                             | √   | 总共多少页 |

#### NodeBaseInfo
##### NodeBaseInfo-节点信息(权限)

| 参数名称              | 参数类型    | 必须  | 参数说明                                                                                                                                                                      |
| ----------------- | ------- | --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| agentHashId       | string  |     | 第三方机器 HashId                                                                                                                                                              |
| agentId           | integer |     | 第三方机器 Id                                                                                                                                                                  |
| agentStatus       | boolean |     | agent状态                                                                                                                                                                   |
| bakOperator       | string  |     | 备份责任人                                                                                                                                                                     |
| bizId             | integer |     | 所属业务, 默认-1表示没有绑定业务                                                                                                                                                        |
| createWorkspaceId | string  |     | 创作环境，工作空间id                                                                                                                                                               |
| createdUser       | string  | √   | 创建人                                                                                                                                                                       |
| displayName       | string  |     | 显示名称                                                                                                                                                                      |
| envEnableNode     | boolean |     | 当前环境是否启用这个 node                                                                                                                                                           |
| gateway           | string  |     | 网关地域                                                                                                                                                                      |
| ip                | string  | √   | IP                                                                                                                                                                        |
| lastModifyTime    | integer |     | 最后更新时间                                                                                                                                                                    |
| name              | string  | √   | 节点名称                                                                                                                                                                      |
| nodeHashId        | string  | √   | 环境 HashId                                                                                                                                                                 |
| nodeId            | string  | √   | 节点 Id                                                                                                                                                                     |
| nodeName          | string  |     | 主机名                                                                                                                                                                       |
| nodeStatus        | string  | √   | 节点状态                                                                                                                                                                      |
| nodeType          | string  | √   | 节点类型                                                                                                                                                                      |
| operator          | string  |     | 责任人                                                                                                                                                                       |
| operatorStatus    | string  |     | 操作人状态：NORMAL 表示操作人正常 / OPERATOR_CHANGED 表示负责人已变更（禁止使用）；可为NULL，为NULL表示未计算。只有nodeType为CMDB的时候，此字段不为空。判断CMDB节点是否责任人变更，条件为 nodeType==CMDB && operatorStatus==OPERATOR_CHANGED |
| osName            | string  |     | 操作系统                                                                                                                                                                      |
| size              | string  |     | 机型                                                                                                                                                                        |

 
