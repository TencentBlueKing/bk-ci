### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/build_failed_tasks
### 资源描述
#### 获取指定构建的失败任务信息
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称         | 参数类型    | 必须  | 参数说明  |
| ------------ | ------- | --- | ----- |
| buildId      | String  | √   | 构建ID  |
| executeCount | integer |     | 执行次数  |
| pipelineId   | String  |     | 流水线ID |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                  | 说明               |
| ------- | --------------------------------------------------------------------- | ---------------- |
| default | [ResultListPipelineFailTaskDetail](#ResultListPipelineFailTaskDetail) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?buildId={buildId}&executeCount={executeCount}&pipelineId={pipelineId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "errorMsg" : "",
    "jobId" : "",
    "jobName" : "",
    "matrixFlag" : false,
    "stageName" : "",
    "stepId" : "",
    "taskId" : "",
    "taskName" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListPipelineFailTaskDetail
##### 数据返回包装模型

| 参数名称    | 参数类型                                                    | 必须  | 参数说明 |
| ------- | ------------------------------------------------------- | --- | ---- |
| data    | List<[PipelineFailTaskDetail](#PipelineFailTaskDetail)> |     | 数据   |
| message | string                                                  |     | 错误信息 |
| status  | integer                                                 | √   | 状态码  |

#### PipelineFailTaskDetail
##### 流水线失败任务详情

| 参数名称       | 参数类型    | 必须  | 参数说明    |
| ---------- | ------- | --- | ------- |
| errorMsg   | string  |     | 失败信息    |
| jobId      | string  | √   | job_id  |
| jobName    | string  |     | job名称   |
| matrixFlag | boolean |     | 是否为矩阵插件 |
| stageName  | string  |     | stage名称 |
| stepId     | string  | √   | step_id |
| taskId     | string  | √   | task_id |
| taskName   | string  |     | task名称  |

 
