### 请求方法/请求路径
#### GET /{apigwType}/v4/environment/projects/{projectId}/usable_server_envs
### 资源描述
#### 获取用户有权限使用的CMDB环境列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                        | 说明               |
| ------- | ----------------------------------------------------------- | ---------------- |
| default | [ResultListEnvWithPermission](#ResultListEnvWithPermission) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "canDelete" : false,
    "canEdit" : false,
    "canUse" : false,
    "createdTime" : 0,
    "createdUser" : "",
    "desc" : "",
    "envHashId" : "",
    "envNodeType" : "",
    "envType" : "",
    "envVars" : [ {
      "lastUpdateTime" : 0,
      "lastUpdateUser" : "",
      "name" : "",
      "secure" : false,
      "value" : ""
    } ],
    "name" : "",
    "nodeCount" : 0,
    "projectName" : "",
    "tags" : [ {
      "canUpdate" : "enum",
      "tagAllowMulValue" : false,
      "tagKeyId" : 0,
      "tagKeyName" : "",
      "tagValues" : [ {
        "canUpdate" : "enum",
        "nodeCount" : 0,
        "tagValueId" : 0,
        "tagValueName" : ""
      } ]
    } ],
    "updatedTime" : 0,
    "updatedUser" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListEnvWithPermission
##### 数据返回包装模型

| 参数名称    | 参数类型                                          | 必须  | 参数说明 |
| ------- | --------------------------------------------- | --- | ---- |
| data    | List<[EnvWithPermission](#EnvWithPermission)> |     | 数据   |
| message | string                                        |     | 错误信息 |
| status  | integer                                       | √   | 状态码  |

#### EnvWithPermission
##### 环境信息(权限)

| 参数名称        | 参数类型                      | 必须  | 参数说明                                                |
| ----------- | ------------------------- | --- | --------------------------------------------------- |
| canDelete   | boolean                   |     | 是否可以删除                                              |
| canEdit     | boolean                   |     | 是否可以编辑                                              |
| canUse      | boolean                   |     | 是否可以使用                                              |
| createdTime | integer                   | √   | 创建时间                                                |
| createdUser | string                    | √   | 创建人                                                 |
| desc        | string                    | √   | 环境描述                                                |
| envHashId   | string                    | √   | 环境 HashId                                           |
| envNodeType | string                    | √   | 环境节点类型（节点环境{NODE}|标签环境{TAG}）                        |
| envType     | string                    | √   | 环境类型（开发环境{DEV}|测试环境{TEST}|构建环境{BUILD}|创作环境{CREATE}） |
| envVars     | List<[EnvVar](#EnvVar)>   |     | 环境变量                                                |
| name        | string                    | √   | 环境名称                                                |
| nodeCount   | integer                   |     | 节点数量                                                |
| projectName | string                    |     | 项目名称                                                |
| tags        | List<[NodeTag](#NodeTag)> |     | 节点所有的标签                                             |
| updatedTime | integer                   | √   | 更新时间                                                |
| updatedUser | string                    | √   | 更新人                                                 |

#### EnvVar
##### 环境变量

| 参数名称           | 参数类型    | 必须  | 参数说明   |
| -------------- | ------- | --- | ------ |
| lastUpdateTime | integer |     | 最后修改时间 |
| lastUpdateUser | string  |     | 最后修改人  |
| name           | string  | √   | 变量名    |
| secure         | boolean | √   | 是否安全变量 |
| value          | string  | √   | 变量值    |

#### NodeTag
##### 节点标签

| 参数名称             | 参数类型                                | 必须  | 参数说明                |
| ---------------- | ----------------------------------- | --- | ------------------- |
| canUpdate        | ENUM(INTERNAL, TRUE, FALSE)         |     | 标签是否可以修改区分          |
| tagAllowMulValue | boolean                             | √   | 当前节点标签是否支持一个节点多个标签值 |
| tagKeyId         | integer                             | √   | 节点标签名ID             |
| tagKeyName       | string                              | √   | 节点标签名               |
| tagValues        | List<[NodeTagValue](#NodeTagValue)> | √   | 节点标签值               |

#### NodeTagValue
##### 节点标签值

| 参数名称         | 参数类型                        | 必须  | 参数说明       |
| ------------ | --------------------------- | --- | ---------- |
| canUpdate    | ENUM(INTERNAL, TRUE, FALSE) |     | 标签是否可以修改区分 |
| nodeCount    | integer                     |     | 标签包含的节点数量  |
| tagValueId   | integer                     | √   | 节点值ID      |
| tagValueName | string                      | √   | 节点值名       |

 
