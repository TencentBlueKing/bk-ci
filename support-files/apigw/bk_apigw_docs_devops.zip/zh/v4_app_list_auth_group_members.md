### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/list_group_members
### 资源描述
#### 查询用户组成员详情列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称         | 参数类型    | 必须  | 参数说明                     |
| ------------ | ------- | --- | ------------------------ |
| groupCode    | String  |     | 用户组Code,CI管理员为CI_MANAGER |
| iamGroupId   | integer |     | IAM用户组ID                 |
| maxExpiredAt | integer |     | 权限过期时间上限(毫秒时间戳)          |
| memberId     | String  |     | 成员ID(用户名或用户组标识等)         |
| memberType   | String  |     | 成员类型(如USER、DEPARTMENT等)  |
| minExpiredAt | integer |     | 权限过期时间下限(毫秒时间戳)          |
| page         | integer |     | 页码,默认1                   |
| pageSize     | integer |     | 每页条数,默认20                |
| resourceCode | String  |     | 资源Code                   |
| resourceType | String  |     | 资源类型(如流水线、代码库等)          |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                          | 说明               |
| ------- | ----------------------------------------------------------------------------- | ---------------- |
| default | [ResultSQLPageAuthResourceGroupMember](#ResultSQLPageAuthResourceGroupMember) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?groupCode={groupCode}&iamGroupId={iamGroupId}&maxExpiredAt={maxExpiredAt}&memberId={memberId}&memberType={memberType}&minExpiredAt={minExpiredAt}&page={page}&pageSize={pageSize}&resourceCode={resourceCode}&resourceType={resourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "records" : [ {
      "expiredTime" : "string",
      "groupCode" : "",
      "iamGroupId" : 0,
      "id" : 0,
      "joinedAt" : "string",
      "memberId" : "",
      "memberName" : "",
      "memberType" : "",
      "projectCode" : "",
      "resourceCode" : "",
      "resourceType" : ""
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultSQLPageAuthResourceGroupMember
##### 数据返回包装模型

| 参数名称    | 参数类型                                                              | 必须  | 参数说明 |
| ------- | ----------------------------------------------------------------- | --- | ---- |
| data    | [SQLPageAuthResourceGroupMember](#SQLPageAuthResourceGroupMember) |     |      |
| message | string                                                            |     | 错误信息 |
| status  | integer                                                           | √   | 状态码  |

#### SQLPageAuthResourceGroupMember
##### 数据

| 参数名称    | 参数类型                                                      | 必须  | 参数说明 |
| ------- | --------------------------------------------------------- | --- | ---- |
| count   | integer                                                   |     |      |
| records | List<[AuthResourceGroupMember](#AuthResourceGroupMember)> |     |      |

#### AuthResourceGroupMember
##### 资源用户组成员信息

| 参数名称         | 参数类型    | 必须  | 参数说明                                |
| ------------ | ------- | --- | ----------------------------------- |
| expiredTime  | string  | √   | 过期时间                                |
| groupCode    | string  | √   | 资源ID                                |
| iamGroupId   | integer | √   | 权限中心组ID                             |
| id           | integer |     |                                     |
| joinedAt     | string  |     | 加入时间                                |
| memberId     | string  | √   | 成员ID, 用户: 英文名, 组织: 组织ID, 人员模板: 模板ID |
| memberName   | string  | √   | 成员名                                 |
| memberType   | string  | √   | 成员类型, 用户/组织/人员模板                    |
| projectCode  | string  | √   | 项目ID                                |
| resourceCode | string  | √   | 资源ID                                |
| resourceType | string  | √   | 资源类型                                |

 
