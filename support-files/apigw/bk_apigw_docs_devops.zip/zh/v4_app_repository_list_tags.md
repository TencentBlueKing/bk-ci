### 请求方法/请求路径
#### GET /{apigwType}/v4/repositories/projects/{projectId}/repository/tags
### 资源描述
#### 获取代码库Tag列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称           | 参数类型           | 必须  | 参数说明                    |
| -------------- | -------------- | --- | ----------------------- |
| page           | integer        |     | 页码，不传默认为1               |
| pageSize       | integer        |     | 每页数量，不传默认为20            |
| repositoryId   | String         | √   | 代码库哈希ID或别名，别名可包含/       |
| repositoryType | ENUM(ID, NAME) | √   | 代码库请求类型，ID-哈希ID，NAME-别名 |
| search         | String         |     | 搜索条件                    |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                        | 说明               |
| ------- | ------------------------------------------- | ---------------- |
| default | [ResultListReference](#ResultListReference) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?page={page}&pageSize={pageSize}&repositoryId={repositoryId}&repositoryType={repositoryType}&search={search}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "linkUrl" : "",
    "name" : "",
    "path" : "",
    "sha" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListReference
##### 数据返回包装模型

| 参数名称    | 参数类型                          | 必须  | 参数说明 |
| ------- | ----------------------------- | --- | ---- |
| data    | List<[Reference](#Reference)> |     | 数据   |
| message | string                        |     | 错误信息 |
| status  | integer                       | √   | 状态码  |

#### Reference
##### 数据

| 参数名称    | 参数类型   | 必须  | 参数说明 |
| ------- | ------ | --- | ---- |
| linkUrl | string |     |      |
| name    | string |     |      |
| path    | string |     |      |
| sha     | string |     |      |

 
