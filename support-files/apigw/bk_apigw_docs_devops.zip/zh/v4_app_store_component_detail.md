### 请求方法/请求路径
#### GET /{apigwType}/v4/store/components/types/{storeType}/ids/{storeId}/component/detail
### 资源描述
#### 根据组件ID获取组件详情
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| storeId   | String | √   | 组件ID       |
| storeType | String | √   | 组件类型       |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                            | 说明               |
| ------- | ----------------------------------------------- | ---------------- |
| default | [ResultStoreDetailInfo](#ResultStoreDetailInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "categoryList" : [ {
      "categoryCode" : "",
      "categoryName" : "",
      "categoryType" : "",
      "createTime" : 0,
      "iconUrl" : "",
      "id" : "",
      "settings" : {
        "string" : ""
      },
      "updateTime" : 0
    } ],
    "certificationFlag" : false,
    "classify" : {
      "classifyCode" : "",
      "classifyName" : "",
      "classifyType" : "",
      "createTime" : 0,
      "id" : "",
      "serviceScope" : "",
      "updateTime" : 0,
      "weight" : 0
    },
    "description" : "",
    "downloads" : 0,
    "editFlag" : false,
    "extData" : {
      "string" : "Any 任意类型，参照实际请求或返回"
    },
    "honorInfos" : [ {
      "createTime" : "string",
      "honorId" : "",
      "honorName" : "",
      "honorTitle" : "",
      "mountFlag" : false
    } ],
    "indexInfos" : [ {
      "description" : "",
      "hover" : "",
      "iconUrl" : "",
      "indexCode" : "",
      "indexLevelName" : "",
      "indexName" : ""
    } ],
    "initProjectCode" : "",
    "installFlag" : false,
    "labelList" : [ {
      "createTime" : 0,
      "id" : "",
      "labelCode" : "",
      "labelName" : "",
      "labelType" : "",
      "serviceScope" : "",
      "updateTime" : 0
    } ],
    "latestFlag" : false,
    "logoUrl" : "",
    "name" : "",
    "ownerStoreCode" : "",
    "publicFlag" : false,
    "rdType" : "",
    "recommendFlag" : false,
    "score" : "number",
    "status" : "",
    "storeCode" : "",
    "storeId" : "",
    "storeType" : "",
    "summary" : "",
    "testProjectCode" : "",
    "type" : "",
    "userCommentInfo" : {
      "commentFlag" : false,
      "commentId" : ""
    },
    "version" : "",
    "versionInfo" : {
      "publisher" : "",
      "releaseType" : "enum",
      "version" : "",
      "versionContent" : ""
    }
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultStoreDetailInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                | 必须  | 参数说明 |
| ------- | ----------------------------------- | --- | ---- |
| data    | [StoreDetailInfo](#StoreDetailInfo) |     |      |
| message | string                              |     | 错误信息 |
| status  | integer                             | √   | 状态码  |

#### StoreDetailInfo
##### 研发商店组件详细信息

| 参数名称              | 参数类型                                          | 必须  | 参数说明                                                                |
| ----------------- | --------------------------------------------- | --- | ------------------------------------------------------------------- |
| categoryList      | List<[Category](#Category)>                   |     | 范畴列表                                                                |
| certificationFlag | boolean                                       | √   | 是否官方认证 true：是 false：否                                               |
| classify          | [Classify](#Classify)                         |     |                                                                     |
| description       | string                                        |     | 描述                                                                  |
| downloads         | integer                                       |     | 下载量                                                                 |
| editFlag          | boolean                                       |     | 是否可编辑                                                               |
| extData           | Map<String, Any>                              |     | 扩展字段集合(组件级+版本级合并，含installPath/installType/installParams/urlScheme等) |
| honorInfos        | List<[HonorInfo](#HonorInfo)>                 |     | 荣誉信息                                                                |
| indexInfos        | List<[StoreIndexInfo](#StoreIndexInfo)>       |     | 指标信息列表                                                              |
| initProjectCode   | string                                        |     | 组件的初始化项目                                                            |
| installFlag       | boolean                                       | √   | 是否有权限安装标识                                                           |
| labelList         | List<[Label](#Label)>                         |     | 标签列表                                                                |
| latestFlag        | boolean                                       | √   | 是否为最新版本 true：最新 false：非最新                                           |
| logoUrl           | string                                        |     | logo链接                                                              |
| name              | string                                        | √   | 组件名称                                                                |
| ownerStoreCode    | string                                        |     | 归属应用标识                                                              |
| publicFlag        | boolean                                       | √   | 是否是公共组件                                                             |
| rdType            | string                                        |     | 研发类型                                                                |
| recommendFlag     | boolean                                       | √   | 是否推荐标识 true：推荐，false：不推荐                                            |
| score             | number                                        |     | 评分                                                                  |
| status            | string                                        | √   | 组件状态                                                                |
| storeCode         | string                                        | √   | 组件标识                                                                |
| storeId           | string                                        | √   | 组件ID                                                                |
| storeType         | string                                        | √   | 组件类型                                                                |
| summary           | string                                        |     | 简介                                                                  |
| testProjectCode   | string                                        |     | 组件的调试项目                                                             |
| type              | string                                        |     | 应用类型                                                                |
| userCommentInfo   | [StoreUserCommentInfo](#StoreUserCommentInfo) | √   |                                                                     |
| version           | string                                        | √   | 组件版本                                                                |
| versionInfo       | [VersionModel](#VersionModel)                 |     |                                                                     |

#### Category
##### 范畴信息

| 参数名称         | 参数类型                | 必须  | 参数说明                                           |
| ------------ | ------------------- | --- | ---------------------------------------------- |
| categoryCode | string              | √   | 范畴代码                                           |
| categoryName | string              | √   | 范畴名称                                           |
| categoryType | string              | √   | 类别 ATOM:插件 TEMPLATE:模板 IMAGE:镜像 IDE_ATOM:IDE插件 |
| createTime   | integer             | √   | 创建日期                                           |
| iconUrl      | string              |     | icon地址                                         |
| id           | string              | √   | 范畴ID                                           |
| settings     | Map<String, string> | √   | 范畴附加属性配置表                                      |
| updateTime   | integer             | √   | 更新日期                                           |

#### Classify
##### 分类信息

| 参数名称         | 参数类型    | 必须  | 参数说明                                           |
| ------------ | ------- | --- | ---------------------------------------------- |
| classifyCode | string  | √   | 分类编码                                           |
| classifyName | string  | √   | 分类名称                                           |
| classifyType | string  | √   | 类别 ATOM:插件 TEMPLATE:模板 IMAGE:镜像 IDE_ATOM:IDE插件 |
| createTime   | integer | √   | 创建日期                                           |
| id           | string  | √   | 分类ID                                           |
| serviceScope | string  |     | 服务范围                                           |
| updateTime   | integer | √   | 更新日期                                           |
| weight       | integer |     | 权重（数值越大代表权重越高）                                 |

#### HonorInfo
##### 荣誉信息

| 参数名称       | 参数类型    | 必须  | 参数说明 |
| ---------- | ------- | --- | ---- |
| createTime | string  | √   | 创建时间 |
| honorId    | string  | √   | 荣誉ID |
| honorName  | string  | √   | 荣誉名称 |
| honorTitle | string  | √   | 荣誉头衔 |
| mountFlag  | boolean | √   | 是否佩戴 |

#### StoreIndexInfo
##### 研发商店指标信息

| 参数名称           | 参数类型   | 必须  | 参数说明   |
| -------------- | ------ | --- | ------ |
| description    | string | √   | 指标描述   |
| hover          | string | √   | 指标状态显示 |
| iconUrl        | string | √   | 图标地址   |
| indexCode      | string | √   | 指标代码   |
| indexLevelName | string | √   | 等级名称   |
| indexName      | string | √   | 指标名称   |

#### Label
##### 标签信息

| 参数名称         | 参数类型    | 必须  | 参数说明                                           |
| ------------ | ------- | --- | ---------------------------------------------- |
| createTime   | integer | √   | 创建日期                                           |
| id           | string  | √   | 标签ID                                           |
| labelCode    | string  | √   | 标签代码                                           |
| labelName    | string  | √   | 标签名称                                           |
| labelType    | string  | √   | 类别 ATOM:插件 TEMPLATE:模板 IMAGE:镜像 IDE_ATOM:IDE插件 |
| serviceScope | string  |     | 服务范围                                           |
| updateTime   | integer | √   | 更新日期                                           |

#### StoreUserCommentInfo
##### 用户评论信息

| 参数名称        | 参数类型    | 必须  | 参数说明                 |
| ----------- | ------- | --- | -------------------- |
| commentFlag | boolean | √   | 是否已评论 true:是，false:否 |
| commentId   | string  |     | 评论ID                 |

#### VersionModel
##### 版本模型

| 参数名称           | 参数类型                                                                                                                              | 必须  | 参数说明   |
| -------------- | --------------------------------------------------------------------------------------------------------------------------------- | --- | ------ |
| publisher      | string                                                                                                                            | √   | 发布者    |
| releaseType    | ENUM(NEW, INCOMPATIBILITY_UPGRADE, COMPATIBILITY_UPGRADE, COMPATIBILITY_FIX, CANCEL_RE_RELEASE, HIS_VERSION_UPGRADE, BRANCH_TEST) | √   | 发布类型   |
| version        | string                                                                                                                            | √   | 版本号    |
| versionContent | string                                                                                                                            | √   | 版本日志内容 |

 
