### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_insight/members/{memberId}/analysis
### 资源描述
#### 成员权限分析报告
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| memberId  | String | √   | 目标成员ID(用户名等)                       |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                              | 说明               |
| ------- | ----------------------------------------------------------------- | ---------------- |
| default | [ResultUserPermissionAnalysisVO](#ResultUserPermissionAnalysisVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "authorizationSummary" : [ {
      "count" : 0,
      "resourceType" : "",
      "resourceTypeName" : ""
    } ],
    "expiredGroupCount" : 0,
    "hasAllPermissions" : false,
    "resourceSummary" : [ {
      "actionSummary" : "",
      "groupCount" : 0,
      "resourceType" : "",
      "resourceTypeName" : ""
    } ],
    "role" : "",
    "roleDisplayName" : "",
    "totalAuthorizationCount" : 0,
    "totalGroupCount" : 0,
    "warnings" : [ "" ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultUserPermissionAnalysisVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                                  | 必须  | 参数说明 |
| ------- | ----------------------------------------------------- | --- | ---- |
| data    | [UserPermissionAnalysisVO](#UserPermissionAnalysisVO) |     |      |
| message | string                                                |     | 错误信息 |
| status  | integer                                               | √   | 状态码  |

#### UserPermissionAnalysisVO
##### 用户权限分析报告

| 参数名称                    | 参数类型                                                    | 必须  | 参数说明          |
| ----------------------- | ------------------------------------------------------- | --- | ------------- |
| authorizationSummary    | List<[AuthorizationSummaryVO](#AuthorizationSummaryVO)> | √   | 授权概况（按资源类型统计） |
| expiredGroupCount       | integer                                                 | √   | 已过期的用户组数量     |
| hasAllPermissions       | boolean                                                 | √   | 是否拥有项目全部权限    |
| resourceSummary         | List<[ResourceSummaryVO](#ResourceSummaryVO)>           | √   | 各资源类型权限概况     |
| role                    | string                                                  | √   | 用户角色标识        |
| roleDisplayName         | string                                                  | √   | 角色显示名称        |
| totalAuthorizationCount | integer                                                 | √   | 授权总数          |
| totalGroupCount         | integer                                                 | √   | 加入的用户组总数      |
| warnings                | List<string>                                            | √   | 告警提示列表        |

#### AuthorizationSummaryVO
##### 授权概况

| 参数名称             | 参数类型    | 必须  | 参数说明   |
| ---------------- | ------- | --- | ------ |
| count            | integer | √   | 授权数量   |
| resourceType     | string  | √   | 资源类型   |
| resourceTypeName | string  | √   | 资源类型名称 |

#### ResourceSummaryVO
##### 资源类型权限概况

| 参数名称             | 参数类型    | 必须  | 参数说明   |
| ---------------- | ------- | --- | ------ |
| actionSummary    | string  |     | 操作权限概要 |
| groupCount       | integer | √   | 用户组数量  |
| resourceType     | string  | √   | 资源类型   |
| resourceTypeName | string  | √   | 资源类型名称 |

 
