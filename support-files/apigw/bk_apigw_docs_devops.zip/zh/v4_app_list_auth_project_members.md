### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/list_project_members
### 资源描述
#### 获取项目全体成员
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称       | 参数类型    | 必须  | 参数说明                    |
| ---------- | ------- | --- | ----------------------- |
| departed   | boolean |     | 是否已离职,true表示仅查离职用户      |
| memberType | String  |     | 成员类型(如USER、DEPARTMENT等) |
| page       | integer |     | 页码,默认1                  |
| pageSize   | integer |     | 每页条数,默认20               |
| userName   | String  |     | 用户名(模糊匹配)               |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                | 说明               |
| ------- | ------------------------------------------------------------------- | ---------------- |
| default | [ResultSQLPageResourceMemberInfo](#ResultSQLPageResourceMemberInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?departed={departed}&memberType={memberType}&page={page}&pageSize={pageSize}&userName={userName}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "records" : [ {
      "departed" : false,
      "id" : "",
      "name" : "",
      "type" : ""
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultSQLPageResourceMemberInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                    | 必须  | 参数说明 |
| ------- | ------------------------------------------------------- | --- | ---- |
| data    | [SQLPageResourceMemberInfo](#SQLPageResourceMemberInfo) |     |      |
| message | string                                                  |     | 错误信息 |
| status  | integer                                                 | √   | 状态码  |

#### SQLPageResourceMemberInfo
##### 数据

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| count   | integer                                         |     |      |
| records | List<[ResourceMemberInfo](#ResourceMemberInfo)> |     |      |

#### ResourceMemberInfo
##### 成员信息

| 参数名称     | 参数类型    | 必须  | 参数说明 |
| -------- | ------- | --- | ---- |
| departed | boolean |     | 是否离职 |
| id       | string  | √   | 成员id |
| name     | string  |     | 成员名称 |
| type     | string  | √   | 成员类型 |

 
