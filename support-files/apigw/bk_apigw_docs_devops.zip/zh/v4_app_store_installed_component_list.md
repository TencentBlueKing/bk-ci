### 请求方法/请求路径
#### GET /{apigwType}/v4/store/components/projects/{projectCode}/types/{storeType}/installed/components/list
### 资源描述
#### 根据项目和实例ID集合获取组件安装记录
### 输入参数说明
#### Path参数

| 参数名称        | 参数类型                                                                | 必须  | 参数说明       |
| ----------- | ------------------------------------------------------------------- | --- | ---------- |
| apigwType   | String                                                              | √   | apigw Type |
| projectCode | String                                                              | √   | 项目代码       |
| storeType   | ENUM(ATOM, TEMPLATE, IMAGE, IDE_ATOM, SERVICE, DEVX, TRIGGER_EVENT) | √   | 组件类型       |

#### Query参数

| 参数名称        | 参数类型         | 必须  | 参数说明                       |
| ----------- | ------------ | --- | -------------------------- |
| instanceIds | List<string> |     | 实例ID集合，支持多个(默认一次最大限制数量为10) |
| page        | integer      |     | 页码                         |
| pageSize    | integer      |     | 每页数量                       |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                  | 说明               |
| ------- | --------------------------------------------------------------------- | ---------------- |
| default | [ResultPageInstalledComponentInfo](#ResultPageInstalledComponentInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?instanceIds={instanceIds}&page={page}&pageSize={pageSize}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "classifyCode" : "",
      "classifyName" : "",
      "extData" : {
        "string" : "Any 任意类型，参照实际请求或返回"
      },
      "installTime" : "",
      "installType" : "",
      "installedVersion" : "",
      "installer" : "",
      "instanceId" : "",
      "instanceName" : "",
      "logoUrl" : "",
      "publisher" : "",
      "storeCode" : "",
      "storeId" : "",
      "storeName" : "",
      "storeType" : "enum"
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPageInstalledComponentInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                      | 必须  | 参数说明 |
| ------- | --------------------------------------------------------- | --- | ---- |
| data    | [PageInstalledComponentInfo](#PageInstalledComponentInfo) |     |      |
| message | string                                                    |     | 错误信息 |
| status  | integer                                                   | √   | 状态码  |

#### PageInstalledComponentInfo
##### 分页数据包装模型

| 参数名称       | 参数类型                                                    | 必须  | 参数说明  |
| ---------- | ------------------------------------------------------- | --- | ----- |
| count      | integer                                                 | √   | 总记录行数 |
| page       | integer                                                 | √   | 第几页   |
| pageSize   | integer                                                 | √   | 每页多少条 |
| records    | List<[InstalledComponentInfo](#InstalledComponentInfo)> | √   | 数据    |
| totalPages | integer                                                 | √   | 总共多少页 |

#### InstalledComponentInfo
##### 已安装组件信息

| 参数名称             | 参数类型                                                                | 必须  | 参数说明                                         |
| ---------------- | ------------------------------------------------------------------- | --- | -------------------------------------------- |
| classifyCode     | string                                                              |     | 分类标识                                         |
| classifyName     | string                                                              |     | 分类名称                                         |
| extData          | Map<String, Any>                                                    | √   | 组件类型个性化扩展信息(由各storeType按需填充，如插件关联流水线数、卸载权限等) |
| installTime      | string                                                              |     | 安装时间                                         |
| installType      | string                                                              |     | 安装类型(INIT:初始化项目 COMMON:安装项目 TEST:调试项目)       |
| installedVersion | string                                                              |     | 项目下已安装的版本号                                   |
| installer        | string                                                              |     | 安装者                                          |
| instanceId       | string                                                              |     | 实例ID                                         |
| instanceName     | string                                                              |     | 实例名称                                         |
| logoUrl          | string                                                              |     | logo地址                                       |
| publisher        | string                                                              |     | 发布者                                          |
| storeCode        | string                                                              | √   | 组件标识                                         |
| storeId          | string                                                              | √   | 组件ID                                         |
| storeName        | string                                                              | √   | 组件名称                                         |
| storeType        | ENUM(ATOM, TEMPLATE, IMAGE, IDE_ATOM, SERVICE, DEVX, TRIGGER_EVENT) | √   | 组件类型                                         |

 
