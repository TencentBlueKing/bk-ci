### 请求方法/请求路径
#### GET /{apigwType}/v4/creative_flows/share_grants
### 资源描述
#### 查询创作流分享授权
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称             | 参数类型   | 必须  | 参数说明     |
| ---------------- | ------ | --- | -------- |
| flowId           | String |     | 分享条目ID   |
| shareId          | String |     | 分享命名空间ID |
| sourcePipelineId | String |     | 源流水线ID   |
| sourceProjectId  | String |     | 源项目ID    |
| talentCode       | String |     | 分身编码     |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                      | 说明               |
| ------- | ------------------------------------------------------------------------- | ---------------- |
| default | [ResultListCreativeFlowShareGrantVo](#ResultListCreativeFlowShareGrantVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?flowId={flowId}&shareId={shareId}&sourcePipelineId={sourcePipelineId}&sourceProjectId={sourceProjectId}&talentCode={talentCode}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "extInfo" : {
      "category" : "",
      "flowDescription" : "",
      "flowName" : "",
      "sourcePipelineName" : "",
      "talentName" : "",
      "talentVersion" : ""
    },
    "flowId" : "",
    "grantedBy" : "",
    "grantedTime" : 0,
    "scene" : "enum",
    "shareId" : "",
    "shareMode" : "enum",
    "sourcePipelineId" : "",
    "sourceProjectId" : "",
    "status" : "enum",
    "talentCode" : "",
    "validateRules" : {
      "envOsType" : ""
    },
    "versionNum" : "",
    "versionScope" : "enum"
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListCreativeFlowShareGrantVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                        | 必须  | 参数说明 |
| ------- | ----------------------------------------------------------- | --- | ---- |
| data    | List<[CreativeFlowShareGrantVo](#CreativeFlowShareGrantVo)> |     | 数据   |
| message | string                                                      |     | 错误信息 |
| status  | integer                                                     | √   | 状态码  |

#### CreativeFlowShareGrantVo
##### 创作流分享授权

| 参数名称             | 参数类型                                                              | 必须  | 参数说明                     |
| ---------------- | ----------------------------------------------------------------- | --- | ------------------------ |
| extInfo          | [CreativeFlowShareExtInfo](#CreativeFlowShareExtInfo)             |     |                          |
| flowId           | string                                                            | √   |                          |
| grantedBy        | string                                                            | √   |                          |
| grantedTime      | integer                                                           | √   |                          |
| scene            | ENUM(TALENT_FOLLOW)                                               | √   |                          |
| shareId          | string                                                            | √   |                          |
| shareMode        | ENUM(COPY)                                                        | √   | 分享形态，当前恒为 COPY           |
| sourcePipelineId | string                                                            | √   |                          |
| sourceProjectId  | string                                                            | √   |                          |
| status           | ENUM(ENABLED, REVOKED)                                            | √   |                          |
| talentCode       | string                                                            |     |                          |
| validateRules    | [CreativeFlowShareValidateRules](#CreativeFlowShareValidateRules) |     |                          |
| versionNum       | string                                                            |     | 发布版本号，形如 V208；LATEST 时为空 |
| versionScope     | ENUM(LATEST, PINNED)                                              | √   |                          |

#### CreativeFlowShareExtInfo
##### 创作流分享扩展信息

| 参数名称               | 参数类型   | 必须  | 参数说明               |
| ------------------ | ------ | --- | ------------------ |
| category           | string |     | manifest 中声明的分类    |
| flowDescription    | string |     | manifest 中声明的条目描述  |
| flowName           | string |     | manifest 中声明的条目展示名 |
| sourcePipelineName | string |     | 源创作流名称，用于目标命名与回执展示 |
| talentName         | string |     | 分身名称               |
| talentVersion      | string |     | 分身版本号              |

#### CreativeFlowShareValidateRules
##### 创作流分享校验规则

| 参数名称      | 参数类型   | 必须  | 参数说明                          |
| --------- | ------ | --- | ----------------------------- |
| envOsType | string |     | 源环境OS类型，如 LINUX/WINDOWS/MACOS |

 
