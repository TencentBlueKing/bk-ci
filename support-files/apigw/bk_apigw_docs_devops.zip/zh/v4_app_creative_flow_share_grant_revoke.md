### 请求方法/请求路径
#### DELETE /{apigwType}/v4/creative_flows/share_grants
### 资源描述
#### 撤销创作流分享授权
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称 | 参数类型                                                                        | 必须   |
| ---- | --------------------------------------------------------------------------- | ---- |
| 撤销请求 | [CreativeFlowShareGrantRevokeRequest](#CreativeFlowShareGrantRevokeRequest) | true |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultInteger](#ResultInteger) | default response |

### Curl 请求样例

```Json
curl -X DELETE '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### DELETE 请求样例

```Json
{
  "flowIds" : [ "" ],
  "shareId" : "",
  "talentCode" : ""
}
```

### default 返回样例

```Json
{
  "data" : 0,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### CreativeFlowShareGrantRevokeRequest
##### 创作流分享授权撤销请求

| 参数名称       | 参数类型         | 必须  | 参数说明                        |
| ---------- | ------------ | --- | --------------------------- |
| flowIds    | List<string> |     | 按分享撤销时的条目ID列表               |
| shareId    | string       |     | 分享ID；与 talentCode 二选一       |
| talentCode | string       |     | 按分身批量撤销；与 shareId 二选一，必须有其一 |

#### ResultInteger
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | integer |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
