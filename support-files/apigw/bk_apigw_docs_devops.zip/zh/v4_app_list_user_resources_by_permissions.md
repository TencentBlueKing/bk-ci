### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/permission/projects/{projectId}/list_user_resources
### 资源描述
#### 查询用户在项目下对指定操作拥有权限的资源实例列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称                                                                                                | 参数类型                                                                    | 必须   |
| --------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------- | ---- |
| 查询条件。userId 可选，不传则查询请求头 X-DEVOPS-UID 对应用户。返回 data.resources 按 actions 顺序排列，无权限时 resourceCodes 为空数组。 | [ListUserResourcesByPermissionsReq](#ListUserResourcesByPermissionsReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                                      | 说明               |
| ------- | ------------------------------------------------------------------------- | ---------------- |
| default | [ResultUserResourcesByPermissionsVO](#ResultUserResourcesByPermissionsVO) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "actions" : [ "" ],
  "resourceType" : "",
  "userId" : ""
}
```

### default 返回样例

```Json
{
  "data" : {
    "projectId" : "",
    "resourceType" : "",
    "resources" : [ {
      "action" : "",
      "permission" : "",
      "resourceCodes" : [ "" ]
    } ],
    "userId" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ListUserResourcesByPermissionsReq
##### 查询用户有权限的资源实例请求

| 参数名称         | 参数类型         | 必须  | 参数说明                                                                                                                                                                                                          |
| ------------ | ------------ | --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| actions      | List<string> | √   | 操作列表。至少一个。推荐传完整 action，格式为 {resourceType}_{permission}，例如 pipeline_view、pipeline_edit、pipeline_execute。也支持只传权限后缀：view、edit、execute。可用操作可通过 GET /v4/auth/metadata/list_actions?resourceType={resourceType} 获取。 |
| resourceType | string       | √   | 资源类型。权限模型中的资源类型标识。常见值：pipeline(流水线)、pipeline_group(流水线组)、repertory(代码库)、credential(凭证)、environment(环境)、env_node(环境节点)、project(项目)。完整列表可通过 GET /v4/auth/metadata/list_resource_types 获取。                       |
| userId       | string       |     | 待查询用户ID。不传则默认查询请求头 X-DEVOPS-UID 对应用户                                                                                                                                                                          |

#### ResultUserResourcesByPermissionsVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                                          | 必须  | 参数说明 |
| ------- | ------------------------------------------------------------- | --- | ---- |
| data    | [UserResourcesByPermissionsVO](#UserResourcesByPermissionsVO) |     |      |
| message | string                                                        |     | 错误信息 |
| status  | integer                                                       | √   | 状态码  |

#### UserResourcesByPermissionsVO
##### 按多个操作查询用户有权限的资源实例结果

| 参数名称         | 参数类型                                                    | 必须  | 参数说明         |
| ------------ | ------------------------------------------------------- | --- | ------------ |
| projectId    | string                                                  | √   | 项目ID(项目英文名)  |
| resourceType | string                                                  | √   | 资源类型         |
| resources    | List<[UserResourceByActionVO](#UserResourceByActionVO)> | √   | 按操作分组的资源实例列表 |
| userId       | string                                                  | √   | 待查询用户ID      |

#### UserResourceByActionVO
##### 单个操作对应的有权限资源

| 参数名称          | 参数类型         | 必须  | 参数说明                                                                     |
| ------------- | ------------ | --- | ------------------------------------------------------------------------ |
| action        | string       | √   | 操作标识。与请求中的 action 对应                                                     |
| permission    | string       | √   | 权限动作。action 的权限后缀，如 view、edit、execute、delete、list                        |
| resourceCodes | List<string> | √   | 资源实例Code列表。用户对该操作有权限的资源Code。无权限时为空数组。若用户拥有项目级或管理员权限，将返回该项目下该类型的全部资源Code。 |

 
