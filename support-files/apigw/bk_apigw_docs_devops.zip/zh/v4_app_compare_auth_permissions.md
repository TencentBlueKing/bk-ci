### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_insight/compare
### 资源描述
#### 权限对比:比较两个用户的权限差异
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称         | 参数类型   | 必须  | 参数说明            |
| ------------ | ------ | --- | --------------- |
| resourceType | String |     | 限定的资源类型,不传则比较全部 |
| userIdA      | String | √   | 用户A的ID          |
| userIdB      | String | √   | 用户B的ID          |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                    | 说明               |
| ------- | ------------------------------------------------------- | ---------------- |
| default | [ResultPermissionCompareVO](#ResultPermissionCompareVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?resourceType={resourceType}&userIdA={userIdA}&userIdB={userIdB}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "commonGroups" : [ {
      "groupId" : 0,
      "groupName" : "",
      "permissions" : [ "" ],
      "resourceName" : "",
      "resourceType" : "",
      "resourceTypeName" : ""
    } ],
    "onlyInA" : [ {
      "groupId" : 0,
      "groupName" : "",
      "permissions" : [ "" ],
      "resourceName" : "",
      "resourceType" : "",
      "resourceTypeName" : ""
    } ],
    "onlyInB" : [ {
      "groupId" : 0,
      "groupName" : "",
      "permissions" : [ "" ],
      "resourceName" : "",
      "resourceType" : "",
      "resourceTypeName" : ""
    } ],
    "summary" : {
      "commonCount" : 0,
      "differenceDescription" : "",
      "onlyInACount" : 0,
      "onlyInBCount" : 0,
      "totalGroupsA" : 0,
      "totalGroupsB" : 0
    },
    "userIdA" : "",
    "userIdB" : "",
    "userNameA" : "",
    "userNameB" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPermissionCompareVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                        | 必须  | 参数说明 |
| ------- | ------------------------------------------- | --- | ---- |
| data    | [PermissionCompareVO](#PermissionCompareVO) |     |      |
| message | string                                      |     | 错误信息 |
| status  | integer                                     | √   | 状态码  |

#### PermissionCompareVO
##### 权限对比结果

| 参数名称         | 参数类型                                                      | 必须  | 参数说明     |
| ------------ | --------------------------------------------------------- | --- | -------- |
| commonGroups | List<[CompareGroupVO](#CompareGroupVO)>                   | √   | 共同拥有的用户组 |
| onlyInA      | List<[CompareGroupVO](#CompareGroupVO)>                   | √   | 仅A拥有的用户组 |
| onlyInB      | List<[CompareGroupVO](#CompareGroupVO)>                   | √   | 仅B拥有的用户组 |
| summary      | [PermissionCompareSummaryVO](#PermissionCompareSummaryVO) | √   |          |
| userIdA      | string                                                    | √   | 用户A的ID   |
| userIdB      | string                                                    | √   | 用户B的ID   |
| userNameA    | string                                                    | √   | 用户A的显示名  |
| userNameB    | string                                                    | √   | 用户B的显示名  |

#### CompareGroupVO
##### 对比用户组信息

| 参数名称             | 参数类型         | 必须  | 参数说明   |
| ---------------- | ------------ | --- | ------ |
| groupId          | integer      | √   | 用户组ID  |
| groupName        | string       | √   | 用户组名称  |
| permissions      | List<string> | √   | 包含的权限  |
| resourceName     | string       | √   | 资源名称   |
| resourceType     | string       | √   | 资源类型   |
| resourceTypeName | string       | √   | 资源类型名称 |

#### PermissionCompareSummaryVO
##### 权限对比摘要

| 参数名称                  | 参数类型    | 必须  | 参数说明    |
| --------------------- | ------- | --- | ------- |
| commonCount           | integer | √   | 共同用户组数量 |
| differenceDescription | string  | √   | 差异描述    |
| onlyInACount          | integer | √   | 仅A拥有的数量 |
| onlyInBCount          | integer | √   | 仅B拥有的数量 |
| totalGroupsA          | integer | √   | A的用户组总数 |
| totalGroupsB          | integer | √   | B的用户组总数 |

 
