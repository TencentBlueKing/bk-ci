### 请求方法/请求路径
#### DELETE /{apigwType}/v4/auth/project/{projectId}/member_manage/members/batch_remove
### 资源描述
#### 批量移除用户组成员
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称               | 参数类型                                            | 必须   |
| ------------------ | ----------------------------------------------- | ---- |
| 批量移除成员请求体(用户组与成员等) | [BatchRemoveMembersReq](#BatchRemoveMembersReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X DELETE '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### DELETE 请求样例

```Json
{
  "groupIds" : [ 0 ],
  "handoverToMemberId" : "",
  "targetMemberId" : ""
}
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### BatchRemoveMembersReq
##### 批量移除用户组成员请求体

| 参数名称               | 参数类型          | 必须  | 参数说明    |
| ------------------ | ------------- | --- | ------- |
| groupIds           | List<integer> | √   | 用户组ID列表 |
| handoverToMemberId | string        |     | 权限交接人ID |
| targetMemberId     | string        | √   | 目标成员ID  |

#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
