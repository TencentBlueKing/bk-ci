### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/logs/latest_logs
### 资源描述
#### 获取当前查询条件下行号最大的N条日志
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称            | 参数类型                          | 必须  | 参数说明                     |
| --------------- | ----------------------------- | --- | ------------------------ |
| archiveFlag     | boolean                       |     | 是否查询归档数据                 |
| buildId         | String                        | √   | 构建ID (b-开头)              |
| containerHashId | String                        |     | 对应containerHashId (c-开头) |
| debug           | boolean                       |     | 是否包含调试日志                 |
| executeCount    | integer                       |     | 执行次数                     |
| jobId           | String                        |     | 对应jobId                  |
| logType         | ENUM(WARN, ERROR, DEBUG, LOG) |     | 过滤日志级别                   |
| pipelineId      | String                        |     | 流水线ID (p-开头)             |
| size            | integer                       |     | 返回日志条数                   |
| stepId          | String                        |     | 对应stepId                 |
| subTag          | String                        |     | 指定subTag                 |
| tag             | String                        |     | 对应elementId (e-开头)       |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                        | 说明               |
| ------- | ------------------------------------------- | ---------------- |
| default | [ResultQueryLogsText](#ResultQueryLogsText) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?archiveFlag={archiveFlag}&buildId={buildId}&containerHashId={containerHashId}&debug={debug}&executeCount={executeCount}&jobId={jobId}&logType={logType}&pipelineId={pipelineId}&size={size}&stepId={stepId}&subTag={subTag}&tag={tag}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "buildId" : "",
    "content" : "",
    "endLineNo" : 0,
    "finished" : false,
    "hasMore" : false,
    "message" : "",
    "startLineNo" : 0,
    "status" : 0,
    "timeUsed" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultQueryLogsText
##### 数据返回包装模型

| 参数名称    | 参数类型                            | 必须  | 参数说明 |
| ------- | ------------------------------- | --- | ---- |
| data    | [QueryLogsText](#QueryLogsText) |     |      |
| message | string                          |     | 错误信息 |
| status  | integer                         | √   | 状态码  |

#### QueryLogsText
##### 文本日志查询模型

| 参数名称        | 参数类型    | 必须  | 参数说明     |
| ----------- | ------- | --- | -------- |
| buildId     | string  | √   | 构建ID     |
| content     | string  | √   | 拼接后的日志内容 |
| endLineNo   | integer | √   | 当前窗口结束行号 |
| finished    | boolean | √   | 是否结束     |
| hasMore     | boolean |     | 是否有后续日志  |
| message     | string  |     | 错误信息     |
| startLineNo | integer | √   | 当前窗口起始行号 |
| status      | integer | √   | 日志查询状态   |
| timeUsed    | integer | √   | 所用时间     |

 
