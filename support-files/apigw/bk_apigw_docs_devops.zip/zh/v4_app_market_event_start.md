### 请求方法/请求路径
#### POST /{apigwType}/v4/market/event/projects/{projectId}/pipelines/{pipelineId}/{eventCode}/start
### 资源描述
#### 通过触发器插件启动流水线
### 输入参数说明
#### Path参数

| 参数名称       | 参数类型   | 必须  | 参数说明       |
| ---------- | ------ | --- | ---------- |
| apigwType  | String | √   | apigw Type |
| eventCode  | String | √   | 事件编码       |
| pipelineId | String | √   | 流水线ID      |
| projectId  | String | √   | 项目ID       |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称 | 参数类型                                                  | 必须   |
| ---- | ----------------------------------------------------- | ---- |
| 启动请求 | [GenericEventStartRequest](#GenericEventStartRequest) | true |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBuildId](#ResultBuildId) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "eventBody" : {
    "string" : ""
  },
  "startParams" : {
    "string" : ""
  }
}
```

### default 返回样例

```Json
{
  "data" : {
    "executeCount" : 0,
    "id" : "",
    "num" : 0,
    "pipelineId" : "",
    "projectId" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### GenericEventStartRequest
##### 研发商店事件触发启动请求

| 参数名称        | 参数类型                | 必须  | 参数说明    |
| ----------- | ------------------- | --- | ------- |
| eventBody   | Map<String, string> |     | 事件消息体   |
| startParams | Map<String, string> |     | 流水线启动参数 |

#### ResultBuildId
##### 数据返回包装模型

| 参数名称    | 参数类型                | 必须  | 参数说明 |
| ------- | ------------------- | --- | ---- |
| data    | [BuildId](#BuildId) |     |      |
| message | string              |     | 错误信息 |
| status  | integer             | √   | 状态码  |

#### BuildId
##### 构建模型-ID

| 参数名称         | 参数类型    | 必须  | 参数说明   |
| ------------ | ------- | --- | ------ |
| executeCount | integer | √   | 当前执行次数 |
| id           | string  | √   | 构建ID   |
| num          | integer |     | 构建编号   |
| pipelineId   | string  |     | 流水线ID  |
| projectId    | string  |     | 项目ID   |

 
