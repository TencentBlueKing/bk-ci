### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/groups/{groupId}/permission_detail
### 资源描述
#### 查询用户组权限详情
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型    | 必须  | 参数说明                               |
| --------- | ------- | --- | ---------------------------------- |
| apigwType | String  | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| groupId   | integer | √   | 权限中心用户组ID                          |
| projectId | String  | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                          | 说明               |
| ------- | ----------------------------------------------------------------------------- | ---------------- |
| default | [ResultListResourceGroupPermissionDTO](#ResultListResourceGroupPermissionDTO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "action" : "",
    "actionRelatedResourceType" : "",
    "groupCode" : "",
    "iamGroupId" : 0,
    "iamResourceCode" : "",
    "id" : 0,
    "projectCode" : "",
    "relatedIamResourceCode" : "",
    "relatedResourceCode" : "",
    "relatedResourceType" : "",
    "resourceCode" : "",
    "resourceType" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListResourceGroupPermissionDTO
##### 数据返回包装模型

| 参数名称    | 参数类型                                                            | 必须  | 参数说明 |
| ------- | --------------------------------------------------------------- | --- | ---- |
| data    | List<[ResourceGroupPermissionDTO](#ResourceGroupPermissionDTO)> |     | 数据   |
| message | string                                                          |     | 错误信息 |
| status  | integer                                                         | √   | 状态码  |

#### ResourceGroupPermissionDTO
##### 资源组权限详情

| 参数名称                      | 参数类型    | 必须  | 参数说明            |
| ------------------------- | ------- | --- | --------------- |
| action                    | string  | √   | 操作              |
| actionRelatedResourceType | string  | √   | 操作关联的资源类型       |
| groupCode                 | string  | √   | 用户组标识           |
| iamGroupId                | integer | √   | 用户组ID           |
| iamResourceCode           | string  | √   | 用户组关联的iam资源code |
| id                        | integer |     | id              |
| projectCode               | string  | √   | 项目code          |
| relatedIamResourceCode    | string  | √   | 组权限关联的iam资源code |
| relatedResourceCode       | string  | √   | 组权限关联的资源code    |
| relatedResourceType       | string  | √   | 组权限关联的资源类型      |
| resourceCode              | string  | √   | 用户组关联的资源code    |
| resourceType              | string  | √   | 用户组关联的资源类型      |

 
