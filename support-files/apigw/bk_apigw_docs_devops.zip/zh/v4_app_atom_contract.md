### 请求方法/请求路径
#### GET /{apigwType}/v4/atoms/atom_contract
### 资源描述
#### 获取插件运行时契约，没有契约时返回空
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称     | 参数类型   | 必须  | 参数说明                           |
| -------- | ------ | --- | ------------------------------ |
| atomCode | String | √   | 插件代码                           |
| view     | String |     | 视图类型：card（默认，精简卡片）/ full（完整契约） |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                  | 说明               |
| ------- | --------------------------------------------------------------------- | ---------------- |
| default | [ResultStoreComponentContractInfo](#ResultStoreComponentContractInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?atomCode={atomCode}&view={view}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "basedOnVersion" : "",
    "contract" : {
      "string" : "Any 任意类型，参照实际请求或返回"
    },
    "coverage" : "",
    "extractBuildId" : "",
    "generatedDescription" : "",
    "lastSeenVersion" : "",
    "propsHash" : "",
    "reportPath" : "",
    "reviewTime" : "string",
    "reviewer" : "",
    "schemaVersion" : "",
    "selectionKeywords" : [ "" ],
    "selectionSummary" : "",
    "sourceCommit" : "",
    "staleFlag" : false,
    "staleReason" : "",
    "storeCode" : "",
    "storeType" : "",
    "updateTime" : "string",
    "view" : "enum"
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultStoreComponentContractInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                      | 必须  | 参数说明 |
| ------- | --------------------------------------------------------- | --- | ---- |
| data    | [StoreComponentContractInfo](#StoreComponentContractInfo) |     |      |
| message | string                                                    |     | 错误信息 |
| status  | integer                                                   | √   | 状态码  |

#### StoreComponentContractInfo
##### 组件运行时契约

| 参数名称                 | 参数类型             | 必须  | 参数说明                    |
| -------------------- | ---------------- | --- | ----------------------- |
| basedOnVersion       | string           | √   | 契约基于的组件版本               |
| contract             | Map<String, Any> | √   | 契约正文，卡片视图为裁剪后的内容        |
| coverage             | string           | √   | 覆盖程度                    |
| extractBuildId       | string           |     | 产出本契约的抽取流水线构建ID，仅完整视图返回 |
| generatedDescription | string           |     | 基于契约生成的详细描述，仅完整视图返回     |
| lastSeenVersion      | string           |     | 发布链路最近看到的最新版本           |
| propsHash            | string           | √   | 基于版本 PROPS 的哈希          |
| reportPath           | string           |     | 原始扫描报告在制品库的路径，仅完整视图返回   |
| reviewTime           | string           |     | 最近核验时间                  |
| reviewer             | string           |     | 最近核验人                   |
| schemaVersion        | string           | √   | 契约格式版本                  |
| selectionKeywords    | List<string>     | √   | 选型用意图词与同义词              |
| selectionSummary     | string           |     | 选型用一句话说明                |
| sourceCommit         | string           |     | 抽取时扫描的代码提交ID            |
| staleFlag            | boolean          | √   | 是否过期                    |
| staleReason          | string           |     | 过期原因                    |
| storeCode            | string           | √   | 组件标识                    |
| storeType            | string           | √   | 组件类型                    |
| updateTime           | string           | √   | 修改时间                    |
| view                 | ENUM(CARD, FULL) | √   | 视图类型                    |

 
