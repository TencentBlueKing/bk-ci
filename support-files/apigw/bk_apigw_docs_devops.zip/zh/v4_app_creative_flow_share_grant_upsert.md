### 请求方法/请求路径
#### POST /{apigwType}/v4/creative_flows/share_grants/batch_upsert
### 资源描述
#### 批量写入创作流分享授权
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称   | 参数类型                                                                        | 必须   |
| ------ | --------------------------------------------------------------------------- | ---- |
| 批量写入请求 | [CreativeFlowShareGrantUpsertRequest](#CreativeFlowShareGrantUpsertRequest) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                                                  | 说明               |
| ------- | ------------------------------------------------------------------------------------- | ---------------- |
| default | [ResultCreativeFlowShareGrantUpsertResult](#ResultCreativeFlowShareGrantUpsertResult) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "flows" : [ {
    "extInfo" : {
      "category" : "",
      "flowDescription" : "",
      "flowName" : "",
      "sourcePipelineName" : "",
      "talentName" : "",
      "talentVersion" : ""
    },
    "flowId" : "",
    "sourcePipelineId" : "",
    "sourceProjectId" : "",
    "versionNum" : ""
  } ],
  "scene" : "enum",
  "shareId" : "",
  "talentCode" : ""
}
```

### default 返回样例

```Json
{
  "data" : {
    "failed" : [ {
      "errorCode" : "",
      "flowId" : "",
      "message" : ""
    } ],
    "granted" : [ {
      "extInfo" : {
        "category" : "",
        "flowDescription" : "",
        "flowName" : "",
        "sourcePipelineName" : "",
        "talentName" : "",
        "talentVersion" : ""
      },
      "flowId" : "",
      "grantedBy" : "",
      "grantedTime" : 0,
      "scene" : "enum",
      "shareId" : "",
      "shareMode" : "enum",
      "sourcePipelineId" : "",
      "sourceProjectId" : "",
      "status" : "enum",
      "talentCode" : "",
      "validateRules" : {
        "envOsType" : ""
      },
      "versionNum" : "",
      "versionScope" : "enum"
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### CreativeFlowShareGrantUpsertRequest
##### 创作流分享授权批量写入请求

| 参数名称       | 参数类型                                                            | 必须  | 参数说明                    |
| ---------- | --------------------------------------------------------------- | --- | ----------------------- |
| flows      | List<[CreativeFlowShareGrantItem](#CreativeFlowShareGrantItem)> | √   | 授权条目列表                  |
| scene      | ENUM(TALENT_FOLLOW)                                             | √   | 分享场景，本迭代仅 TALENT_FOLLOW |
| shareId    | string                                                          | √   | 分享ID                    |
| talentCode | string                                                          |     | 来源分身编码，仅审计与批量撤销         |

#### CreativeFlowShareGrantItem
##### 创作流分享授权条目（写入）

| 参数名称             | 参数类型                                                  | 必须  | 参数说明                        |
| ---------------- | ----------------------------------------------------- | --- | --------------------------- |
| extInfo          | [CreativeFlowShareExtInfo](#CreativeFlowShareExtInfo) |     |                             |
| flowId           | string                                                | √   | 创作流条目ID                     |
| sourcePipelineId | string                                                | √   | 源流水线ID                      |
| sourceProjectId  | string                                                | √   | 源项目ID                       |
| versionNum       | string                                                |     | 发布版本号，形如 V208；缺省表示授权最新已发布版本 |

#### CreativeFlowShareExtInfo
##### 创作流分享扩展信息

| 参数名称               | 参数类型   | 必须  | 参数说明               |
| ------------------ | ------ | --- | ------------------ |
| category           | string |     | manifest 中声明的分类    |
| flowDescription    | string |     | manifest 中声明的条目描述  |
| flowName           | string |     | manifest 中声明的条目展示名 |
| sourcePipelineName | string |     | 源创作流名称，用于目标命名与回执展示 |
| talentName         | string |     | 分身名称               |
| talentVersion      | string |     | 分身版本号              |

#### ResultCreativeFlowShareGrantUpsertResult
##### 数据返回包装模型

| 参数名称    | 参数类型                                                                      | 必须  | 参数说明 |
| ------- | ------------------------------------------------------------------------- | --- | ---- |
| data    | [CreativeFlowShareGrantUpsertResult](#CreativeFlowShareGrantUpsertResult) |     |      |
| message | string                                                                    |     | 错误信息 |
| status  | integer                                                                   | √   | 状态码  |

#### CreativeFlowShareGrantUpsertResult
##### 创作流分享授权批量写入结果

| 参数名称    | 参数类型                                                                  | 必须  | 参数说明 |
| ------- | --------------------------------------------------------------------- | --- | ---- |
| failed  | List<[CreativeFlowShareGrantFailure](#CreativeFlowShareGrantFailure)> | √   |      |
| granted | List<[CreativeFlowShareGrantVo](#CreativeFlowShareGrantVo)>           | √   |      |

#### CreativeFlowShareGrantFailure
##### 创作流分享授权写入失败项

| 参数名称      | 参数类型   | 必须  | 参数说明 |
| --------- | ------ | --- | ---- |
| errorCode | string | √   |      |
| flowId    | string | √   |      |
| message   | string | √   |      |

#### CreativeFlowShareGrantVo
##### 创作流分享授权

| 参数名称             | 参数类型                                                              | 必须  | 参数说明                     |
| ---------------- | ----------------------------------------------------------------- | --- | ------------------------ |
| extInfo          | [CreativeFlowShareExtInfo](#CreativeFlowShareExtInfo)             |     |                          |
| flowId           | string                                                            | √   |                          |
| grantedBy        | string                                                            | √   |                          |
| grantedTime      | integer                                                           | √   |                          |
| scene            | ENUM(TALENT_FOLLOW)                                               | √   |                          |
| shareId          | string                                                            | √   |                          |
| shareMode        | ENUM(COPY)                                                        | √   | 分享形态，当前恒为 COPY           |
| sourcePipelineId | string                                                            | √   |                          |
| sourceProjectId  | string                                                            | √   |                          |
| status           | ENUM(ENABLED, REVOKED)                                            | √   |                          |
| talentCode       | string                                                            |     |                          |
| validateRules    | [CreativeFlowShareValidateRules](#CreativeFlowShareValidateRules) |     |                          |
| versionNum       | string                                                            |     | 发布版本号，形如 V208；LATEST 时为空 |
| versionScope     | ENUM(LATEST, PINNED)                                              | √   |                          |

#### CreativeFlowShareValidateRules
##### 创作流分享校验规则

| 参数名称      | 参数类型   | 必须  | 参数说明                          |
| --------- | ------ | --- | ----------------------------- |
| envOsType | string |     | 源环境OS类型，如 LINUX/WINDOWS/MACOS |

 
