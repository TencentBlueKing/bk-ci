### 请求方法/请求路径
#### GET /{apigwType}/v4/repositories/oauth/oauthStatus
### 资源描述
#### 获取用户OAUTH授权状态
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称        | 参数类型   | 必须  | 参数说明                                                                      |
| ----------- | ------ | --- | ------------------------------------------------------------------------- |
| redirectUrl | String |     | 授权成功后的跳转地址，不传则跳转到蓝盾代码库页面                                                  |
| scmCode     | String | √   | 代码库类型标识，可选值：CODE_GIT(工蜂)、GITHUB(GitHub)、CODE_TGIT(社区版工蜂)，自定义代码源传入对应的代码源标识 |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                          | 说明               |
| ------- | --------------------------------------------- | ---------------- |
| default | [ResultScmOauthStatus](#ResultScmOauthStatus) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?redirectUrl={redirectUrl}&scmCode={scmCode}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "authorized" : false,
    "url" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultScmOauthStatus
##### 数据返回包装模型

| 参数名称    | 参数类型                              | 必须  | 参数说明 |
| ------- | --------------------------------- | --- | ---- |
| data    | [ScmOauthStatus](#ScmOauthStatus) |     |      |
| message | string                            |     | 错误信息 |
| status  | integer                           | √   | 状态码  |

#### ScmOauthStatus
##### 代码库OAUTH授权状态

| 参数名称       | 参数类型    | 必须  | 参数说明         |
| ---------- | ------- | --- | ------------ |
| authorized | boolean | √   | 是否已完成OAUTH授权 |
| url        | string  |     | OAUTH授权链接    |

 
