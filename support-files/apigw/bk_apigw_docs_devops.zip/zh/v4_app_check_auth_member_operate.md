### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/member_manage/members/{batchOperateType}/check
### 资源描述
#### 批量操作成员检查
### 输入参数说明
#### Path参数

| 参数名称             | 参数类型                            | 必须  | 参数说明                               |
| ---------------- | ------------------------------- | --- | ---------------------------------- |
| apigwType        | String                          | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| batchOperateType | ENUM(RENEWAL, REMOVE, HANDOVER) | √   | 批量操作类型(续期、移除、交接等)                  |
| projectId        | String                          | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称        | 参数类型                                          | 必须   |
| ----------- | --------------------------------------------- | ---- |
| 批量操作前置检查请求体 | [BatchOperateCheckReq](#BatchOperateCheckReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                                          | 说明               |
| ------- | ----------------------------------------------------------------------------- | ---------------- |
| default | [ResultBatchOperateGroupMemberCheckVo](#ResultBatchOperateGroupMemberCheckVo) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "groupIds" : [ 0 ],
  "targetMemberId" : ""
}
```

### default 返回样例

```Json
{
  "data" : {
    "canHandoverCount" : 0,
    "inoperableCount" : 0,
    "invalidEnvNodeAuthorizationCount" : 0,
    "invalidGroupCount" : 0,
    "invalidPipelineAuthorizationCount" : 0,
    "invalidRepositoryAuthorizationCount" : 0,
    "needToHandover" : false,
    "operableCount" : 0,
    "totalCount" : 0,
    "uniqueManagerCount" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### BatchOperateCheckReq
##### 批量操作用户组成员检查请求体

| 参数名称           | 参数类型          | 必须  | 参数说明    |
| -------------- | ------------- | --- | ------- |
| groupIds       | List<integer> | √   | 用户组ID列表 |
| targetMemberId | string        | √   | 目标成员ID  |

#### ResultBatchOperateGroupMemberCheckVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                              | 必须  | 参数说明 |
| ------- | ----------------------------------------------------------------- | --- | ---- |
| data    | [BatchOperateGroupMemberCheckVo](#BatchOperateGroupMemberCheckVo) |     |      |
| message | string                                                            |     | 错误信息 |
| status  | integer                                                           | √   | 状态码  |

#### BatchOperateGroupMemberCheckVo
##### 批量续期/删除/交接/组成员检查

| 参数名称                                | 参数类型    | 必须  | 参数说明        |
| ----------------------------------- | ------- | --- | ----------- |
| canHandoverCount                    | integer |     | 可交接的组数量     |
| inoperableCount                     | integer |     | 无法操作的数量     |
| invalidEnvNodeAuthorizationCount    | integer |     | 无效的环境节点授权数量 |
| invalidGroupCount                   | integer |     | 导致代持人失效的用户组 |
| invalidPipelineAuthorizationCount   | integer |     | 无效的流水线授权数量  |
| invalidRepositoryAuthorizationCount | integer |     | 无效的代码库授权数量  |
| needToHandover                      | boolean |     | 是否需要交接      |
| operableCount                       | integer |     | 可操作的数量      |
| totalCount                          | integer | √   | 总数          |
| uniqueManagerCount                  | integer |     | 唯一管理员组的数量   |

 
