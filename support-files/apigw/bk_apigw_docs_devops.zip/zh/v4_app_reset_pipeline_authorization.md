### 请求方法/请求路径
#### PUT /{apigwType}/v4/auth/authorization/{projectId}/pipelines/{pipelineId}/reset_authorization
### 资源描述
#### 重置流水线授权人
### 输入参数说明
#### Path参数

| 参数名称       | 参数类型   | 必须  | 参数说明       |
| ---------- | ------ | --- | ---------- |
| apigwType  | String | √   | apigw Type |
| pipelineId | String | √   | 流水线Id      |
| projectId  | String | √   | 项目Id       |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称       | 参数类型                                                            | 必须   |
| ---------- | --------------------------------------------------------------- | ---- |
| 重置流水线授权请求体 | [ResetPipelineAuthorizationReq](#ResetPipelineAuthorizationReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                                          | 说明               |
| ------- | ----------------------------------------------------------------------------- | ---------------- |
| default | [ResultResetPipelineAuthorizationResp](#ResultResetPipelineAuthorizationResp) | default response |

### Curl 请求样例

```Json
curl -X PUT '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### PUT 请求样例

```Json
{
  "handoverTo" : ""
}
```

### default 返回样例

```Json
{
  "data" : {
    "failedReason" : "",
    "success" : false
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResetPipelineAuthorizationReq
##### 重置流水线授权请求体

| 参数名称       | 参数类型   | 必须  | 参数说明  |
| ---------- | ------ | --- | ----- |
| handoverTo | string | √   | 新的授权人 |

#### ResultResetPipelineAuthorizationResp
##### 数据返回包装模型

| 参数名称    | 参数类型                                                              | 必须  | 参数说明 |
| ------- | ----------------------------------------------------------------- | --- | ---- |
| data    | [ResetPipelineAuthorizationResp](#ResetPipelineAuthorizationResp) |     |      |
| message | string                                                            |     | 错误信息 |
| status  | integer                                                           | √   | 状态码  |

#### ResetPipelineAuthorizationResp
##### 重置流水线授权响应体

| 参数名称         | 参数类型    | 必须  | 参数说明          |
| ------------ | ------- | --- | ------------- |
| failedReason | string  |     | 失败原因，成功时为null |
| success      | boolean | √   | 是否重置成功        |

 
