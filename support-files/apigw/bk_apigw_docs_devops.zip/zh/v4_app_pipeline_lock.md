### 请求方法/请求路径
#### POST /{apigwType}/v4/projects/{projectId}/pipelines/pipeline_lock
### 资源描述
#### 启用/禁用流水线（修改流水线的并发设置）
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称       | 参数类型    | 必须  | 参数说明           |
| ---------- | ------- | --- | -------------- |
| enable     | boolean | √   | 开启true/锁定false |
| pipelineId | String  | √   | 流水线ID          |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称     | 参数类型                                        | 必须  |
| -------- | ------------------------------------------- | --- |
| 启用/禁用请求体 | [PipelineLockRequest](#PipelineLockRequest) |     |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]?enable={enable}&pipelineId={pipelineId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "lockReason" : ""
}
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### PipelineLockRequest
##### 流水线启用/禁用请求

| 参数名称       | 参数类型   | 必须  | 参数说明          |
| ---------- | ------ | --- | ------------- |
| lockReason | string |     | 禁用原因，最多120个字符 |

#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
