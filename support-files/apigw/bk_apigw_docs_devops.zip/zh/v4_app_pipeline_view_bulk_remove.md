### 请求方法/请求路径
#### POST /{apigwType}/v4/projects/{projectId}/pipelineView/bulkRemove
### 资源描述
#### 流水线组下批量移除流水线
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明 |
| --------- | ------ | --- | ---- |
| projectId | String | √   | 项目ID |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称                   | 参数类型                                              | 必须  |
| ---------------------- | ------------------------------------------------- | --- |
| 批量移除请求，从指定静态流水线组中移除流水线 | [PipelineViewBulkRemove](#PipelineViewBulkRemove) |     |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "pipelineIds" : [ "" ],
  "viewId" : ""
}
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### PipelineViewBulkRemove
##### 流水线组批量移除

| 参数名称        | 参数类型         | 必须  | 参数说明    |
| ----------- | ------------ | --- | ------- |
| pipelineIds | List<string> | √   | 流水线ID列表 |
| viewId      | string       | √   | 视图ID    |

#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
