### 请求方法/请求路径
#### PUT /{apigwType}/v4/environment/projects/{projectId}/enable_env_node
### 资源描述
#### 环境中启用/停用节点
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称       | 参数类型    | 必须  | 参数说明                 |
| ---------- | ------- | --- | -------------------- |
| enable     | boolean | √   | 启动true/停用false       |
| envHashId  | String  | √   | 环境 hashId（优先）        |
| envName    | String  | √   | 环境名称（与环境 hashId 二选一） |
| nodeHashId | String  | √   | 节点 hashId（优先）        |
| nodeName   | String  | √   | 节点名称（与节点 hashId 二选一） |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X PUT '[请替换为上方API地址栏请求地址]?enable={enable}&envHashId={envHashId}&envName={envName}&nodeHashId={nodeHashId}&nodeName={nodeName}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
