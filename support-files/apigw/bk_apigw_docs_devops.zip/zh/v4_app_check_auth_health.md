### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_insight/authorization/health_check
### 资源描述
#### 项目授权健康检查:扫描授权风险
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                        | 说明               |
| ------- | ----------------------------------------------------------- | ---------------- |
| default | [ResultAuthorizationHealthVO](#ResultAuthorizationHealthVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "authorizationStats" : {
      "envNodeAuthorizationCount" : 0,
      "pipelineAuthorizationCount" : 0,
      "repertoryAuthorizationCount" : 0,
      "totalAuthorizerCount" : 0,
      "uniqueManagerGroupCount" : 0
    },
    "checkTime" : 0,
    "healthStatus" : "",
    "projectId" : "",
    "riskCount" : 0,
    "risks" : [ {
      "affectedUser" : "",
      "description" : "",
      "level" : "",
      "resourceCode" : "",
      "resourceName" : "",
      "resourceType" : "",
      "riskType" : "",
      "suggestion" : ""
    } ],
    "suggestions" : [ "" ],
    "warningCount" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultAuthorizationHealthVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | [AuthorizationHealthVO](#AuthorizationHealthVO) |     |      |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### AuthorizationHealthVO
##### 授权健康检查结果

| 参数名称               | 参数类型                                              | 必须  | 参数说明   |
| ------------------ | ------------------------------------------------- | --- | ------ |
| authorizationStats | [AuthorizationStatsVO](#AuthorizationStatsVO)     | √   |        |
| checkTime          | integer                                           | √   | 检查时间   |
| healthStatus       | string                                            | √   | 整体健康状态 |
| projectId          | string                                            | √   | 项目ID   |
| riskCount          | integer                                           | √   | 风险数量   |
| risks              | List<[AuthorizationRiskVO](#AuthorizationRiskVO)> | √   | 风险项列表  |
| suggestions        | List<string>                                      | √   | 建议操作   |
| warningCount       | integer                                           | √   | 警告数量   |

#### AuthorizationStatsVO
##### 授权统计

| 参数名称                        | 参数类型    | 必须  | 参数说明       |
| --------------------------- | ------- | --- | ---------- |
| envNodeAuthorizationCount   | integer | √   | 环境节点授权总数   |
| pipelineAuthorizationCount  | integer | √   | 流水线授权总数    |
| repertoryAuthorizationCount | integer | √   | 代码库授权总数    |
| totalAuthorizerCount        | integer | √   | 授权人总数      |
| uniqueManagerGroupCount     | integer | √   | 唯一管理员用户组数量 |

#### AuthorizationRiskVO
##### 授权风险项

| 参数名称         | 参数类型   | 必须  | 参数说明      |
| ------------ | ------ | --- | --------- |
| affectedUser | string |     | 涉及的用户     |
| description  | string | √   | 风险描述      |
| level        | string | √   | 风险级别      |
| resourceCode | string |     | 涉及的资源Code |
| resourceName | string |     | 涉及的资源名称   |
| resourceType | string |     | 涉及的资源类型   |
| riskType     | string | √   | 风险类型      |
| suggestion   | string |     | 建议操作      |

 
