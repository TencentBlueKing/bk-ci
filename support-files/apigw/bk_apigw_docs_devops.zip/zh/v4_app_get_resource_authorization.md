### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/authorization/{projectId}/{resourceType}/{resourceCode}/get_resource_authorization
### 资源描述
#### 获取资源授予记录
### 输入参数说明
#### Path参数

| 参数名称         | 参数类型   | 必须  | 参数说明       |
| ------------ | ------ | --- | ---------- |
| apigwType    | String | √   | apigw Type |
| projectId    | String | √   | 项目Id       |
| resourceCode | String | √   | 资源code     |
| resourceType | String | √   | 资源类型       |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                        | 说明               |
| ------- | --------------------------------------------------------------------------- | ---------------- |
| default | [ResultResourceAuthorizationResponse](#ResultResourceAuthorizationResponse) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "approver" : "",
    "beingHandover" : false,
    "executePermission" : false,
    "handoverFrom" : "",
    "handoverFromCnName" : "",
    "handoverTime" : 0,
    "id" : 0,
    "projectCode" : "",
    "resourceCode" : "",
    "resourceName" : "",
    "resourceType" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultResourceAuthorizationResponse
##### 数据返回包装模型

| 参数名称    | 参数类型                                                            | 必须  | 参数说明 |
| ------- | --------------------------------------------------------------- | --- | ---- |
| data    | [ResourceAuthorizationResponse](#ResourceAuthorizationResponse) |     |      |
| message | string                                                          |     | 错误信息 |
| status  | integer                                                         | √   | 状态码  |

#### ResourceAuthorizationResponse
##### 资源授权返回体

| 参数名称               | 参数类型    | 必须  | 参数说明            |
| ------------------ | ------- | --- | --------------- |
| approver           | string  |     | 交接审批人           |
| beingHandover      | boolean |     | 是否正在交接，用于我的授权界面 |
| executePermission  | boolean |     | 是否有执行权限         |
| handoverFrom       | string  | √   | 授予人             |
| handoverFromCnName | string  |     | 授予人中文名称         |
| handoverTime       | integer | √   | 授权时间            |
| id                 | integer |     | ID              |
| projectCode        | string  | √   | 项目ID            |
| resourceCode       | string  | √   | 资源code          |
| resourceName       | string  | √   | 资源名称            |
| resourceType       | string  | √   | 资源类型            |

 
