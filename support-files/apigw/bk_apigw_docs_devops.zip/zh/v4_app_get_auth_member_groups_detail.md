### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/members/{resourceType}/groups
### 资源描述
#### 获取成员用户组详情
### 输入参数说明
#### Path参数

| 参数名称         | 参数类型   | 必须  | 参数说明                               |
| ------------ | ------ | --- | ---------------------------------- |
| apigwType    | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId    | String | √   | 项目ID(项目英文名)                        |
| resourceType | String | √   | 资源类型(路径参数,与权限模型中的资源类型一致)           |

#### Query参数

| 参数名称                | 参数类型    | 必须  | 参数说明         |
| ------------------- | ------- | --- | ------------ |
| memberId            | String  | √   | 目标成员ID(用户名等) |
| page                | integer |     | 页码,默认1       |
| pageSize            | integer |     | 每页条数,默认20    |
| relatedResourceCode | String  |     | 关联资源Code     |
| relatedResourceType | String  |     | 关联资源类型       |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                | 说明               |
| ------- | ------------------------------------------------------------------- | ---------------- |
| default | [ResultSQLPageGroupDetailsInfoVo](#ResultSQLPageGroupDetailsInfoVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?memberId={memberId}&page={page}&pageSize={pageSize}&relatedResourceCode={relatedResourceCode}&relatedResourceType={relatedResourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "records" : [ {
      "beingHandedOver" : false,
      "expiredAt" : 0,
      "expiredAtDisplay" : "",
      "flowNo" : "",
      "groupDesc" : "",
      "groupId" : 0,
      "groupName" : "",
      "joinedTime" : 0,
      "joinedType" : "enum",
      "memberType" : "enum",
      "operator" : "",
      "removeMemberButtonControl" : "enum",
      "resourceCode" : "",
      "resourceName" : "",
      "resourceType" : ""
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultSQLPageGroupDetailsInfoVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                    | 必须  | 参数说明 |
| ------- | ------------------------------------------------------- | --- | ---- |
| data    | [SQLPageGroupDetailsInfoVo](#SQLPageGroupDetailsInfoVo) |     |      |
| message | string                                                  |     | 错误信息 |
| status  | integer                                                 | √   | 状态码  |

#### SQLPageGroupDetailsInfoVo
##### 数据

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| count   | integer                                         |     |      |
| records | List<[GroupDetailsInfoVo](#GroupDetailsInfoVo)> |     |      |

#### GroupDetailsInfoVo
##### 用户组详细信息

| 参数名称                      | 参数类型                                                            | 必须  | 参数说明     |
| ------------------------- | --------------------------------------------------------------- | --- | -------- |
| beingHandedOver           | boolean                                                         |     | 是否正在交接   |
| expiredAt                 | integer                                                         | √   | 过期时间戳，毫秒 |
| expiredAtDisplay          | string                                                          | √   | 有效期，天    |
| flowNo                    | string                                                          |     | 交接单号     |
| groupDesc                 | string                                                          |     | 用户组描述    |
| groupId                   | integer                                                         | √   | 用户组ID    |
| groupName                 | string                                                          | √   | 用户组名称    |
| joinedTime                | integer                                                         | √   | 加入时间     |
| joinedType                | ENUM(DIRECT, TEMPLATE, DEPARTMENT)                              | √   | 加入方式     |
| memberType                | ENUM(USER, DEPARTMENT, TEMPLATE)                                |     | 组成员类型    |
| operator                  | string                                                          | √   | 操作人      |
| removeMemberButtonControl | ENUM(UNIQUE_MANAGER, UNIQUE_OWNER, TEMPLATE, DEPARTMENT, OTHER) | √   | 移除成员按钮控制 |
| resourceCode              | string                                                          | √   | 资源实例code |
| resourceName              | string                                                          | √   | 资源实例名称   |
| resourceType              | string                                                          | √   | 资源类型     |

 
