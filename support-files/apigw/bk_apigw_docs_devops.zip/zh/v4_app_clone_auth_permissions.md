### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/member_manage/permissions/clone
### 资源描述
#### 权限克隆:将来源用户的权限复制给目标用户
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称          | 参数类型    | 必须  | 参数说明                        |
| ------------- | ------- | --- | --------------------------- |
| dryRun        | boolean |     | 是否预检查模式,默认true(仅返回差异,不真正执行) |
| resourceTypes | String  |     | 限定的资源类型列表(多个以逗号分隔),不传则覆盖全部  |
| sourceUserId  | String  | √   | 来源用户ID                      |
| targetUserId  | String  | √   | 目标用户ID                      |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                            | 说明               |
| ------- | --------------------------------------------------------------- | ---------------- |
| default | [ResultPermissionCloneResultVO](#ResultPermissionCloneResultVO) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]?dryRun={dryRun}&resourceTypes={resourceTypes}&sourceUserId={sourceUserId}&targetUserId={targetUserId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "dryRun" : false,
    "failedCount" : 0,
    "failedDetails" : [ {
      "groupId" : 0,
      "groupName" : "",
      "reason" : ""
    } ],
    "groupsToClone" : [ {
      "groupId" : 0,
      "groupName" : "",
      "permissions" : [ "" ],
      "resourceName" : "",
      "resourceType" : ""
    } ],
    "skippedGroups" : [ {
      "groupId" : 0,
      "groupName" : "",
      "permissions" : [ "" ],
      "resourceName" : "",
      "resourceType" : ""
    } ],
    "sourceUserId" : "",
    "successCount" : 0,
    "summary" : "",
    "targetUserId" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPermissionCloneResultVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                                | 必须  | 参数说明 |
| ------- | --------------------------------------------------- | --- | ---- |
| data    | [PermissionCloneResultVO](#PermissionCloneResultVO) |     |      |
| message | string                                              |     | 错误信息 |
| status  | integer                                             | √   | 状态码  |

#### PermissionCloneResultVO
##### 权限克隆结果

| 参数名称          | 参数类型                                              | 必须  | 参数说明            |
| ------------- | ------------------------------------------------- | --- | --------------- |
| dryRun        | boolean                                           | √   | 是否预检查模式         |
| failedCount   | integer                                           | √   | 克隆失败的用户组数量      |
| failedDetails | List<[CloneFailedDetailVO](#CloneFailedDetailVO)> | √   | 失败详情            |
| groupsToClone | List<[GroupCloneInfoVO](#GroupCloneInfoVO)>       | √   | 将要克隆的用户组列表      |
| skippedGroups | List<[GroupCloneInfoVO](#GroupCloneInfoVO)>       | √   | 已跳过的用户组（目标用户已有） |
| sourceUserId  | string                                            | √   | 来源用户ID          |
| successCount  | integer                                           | √   | 克隆成功的用户组数量      |
| summary       | string                                            |     | 执行摘要            |
| targetUserId  | string                                            | √   | 目标用户ID          |

#### CloneFailedDetailVO
##### 克隆失败详情

| 参数名称      | 参数类型    | 必须  | 参数说明  |
| --------- | ------- | --- | ----- |
| groupId   | integer | √   | 用户组ID |
| groupName | string  | √   | 用户组名称 |
| reason    | string  | √   | 失败原因  |

#### GroupCloneInfoVO
##### 用户组克隆信息

| 参数名称         | 参数类型         | 必须  | 参数说明  |
| ------------ | ------------ | --- | ----- |
| groupId      | integer      | √   | 用户组ID |
| groupName    | string       | √   | 用户组名称 |
| permissions  | List<string> | √   | 包含的权限 |
| resourceName | string       | √   | 资源名称  |
| resourceType | string       | √   | 资源类型  |

 
