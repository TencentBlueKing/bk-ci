### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/batch_add_resource_group_members
### 资源描述
#### 用户组批量添加成员
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| projectId | String | √   | projectId  |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称 | 参数类型                                            | 必须   |
| ---- | ----------------------------------------------- | ---- |
| 添加信息 | [ProjectCreateUserInfo](#ProjectCreateUserInfo) | true |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "createUserId" : "",
  "deptIds" : [ "" ],
  "expiredTime" : 0,
  "groupId" : 0,
  "resourceCode" : "",
  "resourceType" : "",
  "roleId" : 0,
  "roleName" : "",
  "userIds" : [ "" ]
}
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ProjectCreateUserInfo
##### 

| 参数名称         | 参数类型         | 必须  | 参数说明                                                                                                                 |
| ------------ | ------------ | --- | -------------------------------------------------------------------------------------------------------------------- |
| createUserId | string       |     | 操作人:发起本次添加操作的用户 ID，一般传当前操作者即可。                                                                                       |
| deptIds      | List<string> |     | 目标部门:要加入用户组的部门 ID 列表，支持批量传入。                                                                                         |
| expiredTime  | integer      |     | 过期天数：成员有效期，单位为天。例如传 30 表示 30 天后过期；不传默认 365 天。                                                                        |
| groupId      | integer      |     | 组ID:用户组 ID。已知具体用户组时，优先传该字段。                                                                                          |
| resourceCode | string       |     | 资源ID：如流水线id等。未传 groupId 时建议填写。                                                                                       |
| resourceType | string       |     | 资源类型:资源类型，例如 project、pipeline。未传 groupId 时建议填写；不传默认按 project 处理。                                                     |
| roleId       | integer      |     | 角色Id:历史角色 ID，仅兼容旧版调用。可选值：0=visitor，2=manager，4=developer，5=maintainer，6=pm，7=qc，8=tester。已传 groupId 或 roleName 时可不传。 |
| roleName     | string       |     | 角色名称:要添加到的角色名称，例如 manager、developer、viewer、executor。已知 groupId 时可不传。                                                 |
| userIds      | List<string> |     | 目标用户:要加入用户组的用户 ID 列表，支持批量传入。                                                                                         |

#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
