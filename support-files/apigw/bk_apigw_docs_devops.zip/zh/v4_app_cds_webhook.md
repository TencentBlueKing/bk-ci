### 请求方法/请求路径
#### POST /{apigwType}/v4/market/event/{eventCode}/webhook/cds
### 资源描述
#### 云桌面webhook事件推送
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| eventCode | String | √   | 事件编码       |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称                    | 参数类型   | 必须  | 参数说明                |
| ----------------------- | ------ | --- | ------------------- |
| Content-Type            | string | √   | application/json    |
| X-DEVOPS-UID            | string | √   | 用户名                 |
| X-DEVOPS-PROJECT-ID     | String |     | 项目ID                |
| x-devops-cds-event-type | String |     | x-devops-event-type |
| x-devops-cds-ip         | String |     | x-devops-cds-ip     |
| x-devops-workspace-name | String |     | 实例化id               |

#### Body参数

| 参数名称 | 参数类型                | 必须  |
| ---- | ------------------- | --- |
|      | Map<String, string> |     |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' \
-H 'X-DEVOPS-PROJECT-ID: 项目ID' \
-H 'x-devops-cds-event-type: x-devops-event-type' \
-H 'x-devops-cds-ip: x-devops-cds-ip' \
-H 'x-devops-workspace-name: 实例化id' 
```

### POST 请求样例

```Json
{ }
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
