### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/groups_for_apply
### 资源描述
#### 查询可申请的用户组列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称                                  | 参数类型    | 必须  | 参数说明                           |
| ------------------------------------- | ------- | --- | ------------------------------ |
| actionId                              | String  |     | 操作id筛选                         |
| description                           | String  |     | 用户组描述                          |
| groupId                               | integer |     | 用户组id                          |
| groupLevel                            | String  |     | 用户组级别(PROJECT-项目级/OTHER-其他资源级) |
| iamResourceCode                       | String  |     | IAM资源实例筛选                      |
| name                                  | String  |     | 用户组名称                          |
| page                                  | integer |     | 页码,默认1                         |
| pageSize                              | integer |     | 每页条数,默认20                      |
| resourceCode                          | String  |     | 资源实例筛选                         |
| resourceType(流水线-pipeline,项目-project) | String  |     | 资源类型筛选                         |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                  | 说明               |
| ------- | ----------------------------------------------------- | ---------------- |
| default | [ResultManagerRoleGroupVO](#ResultManagerRoleGroupVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?actionId={actionId}&description={description}&groupId={groupId}&groupLevel={groupLevel}&iamResourceCode={iamResourceCode}&name={name}&page={page}&pageSize={pageSize}&resourceCode={resourceCode}&resourceType(流水线-pipeline,项目-project)={resourceType(流水线-pipeline,项目-project)}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "results" : [ {
      "departmentCount" : 0,
      "description" : "",
      "id" : 0,
      "joined" : false,
      "name" : "",
      "readonly" : false,
      "resourceCode" : "",
      "resourceName" : "",
      "resourceType" : "",
      "resourceTypeName" : "",
      "userCount" : 0
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultManagerRoleGroupVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                      | 必须  | 参数说明 |
| ------- | ----------------------------------------- | --- | ---- |
| data    | [ManagerRoleGroupVO](#ManagerRoleGroupVO) |     |      |
| message | string                                    |     | 错误信息 |
| status  | integer                                   | √   | 状态码  |

#### ManagerRoleGroupVO
##### 用户组信息返回实体

| 参数名称    | 参数类型                                                | 必须  | 参数说明  |
| ------- | --------------------------------------------------- | --- | ----- |
| count   | integer                                             | √   | 用户组数量 |
| results | List<[ManagerRoleGroupInfo](#ManagerRoleGroupInfo)> | √   | 用户组信息 |

#### ManagerRoleGroupInfo
##### 用户组详细信息

| 参数名称             | 参数类型    | 必须  | 参数说明              |
| ---------------- | ------- | --- | ----------------- |
| departmentCount  | integer | √   | 用户组成员department数量 |
| description      | string  | √   | 描述                |
| id               | integer | √   | 用户组id             |
| joined           | boolean | √   | 是否已经加入用户组         |
| name             | string  | √   | 名称                |
| readonly         | boolean | √   | 是否是只读用户组          |
| resourceCode     | string  | √   | 用户组关联的资源实例code    |
| resourceName     | string  | √   | 用户组关联的资源实例名称      |
| resourceType     | string  | √   | 用户组关联的资源类型        |
| resourceTypeName | string  | √   | 用户组关联的资源类型名称      |
| userCount        | integer | √   | 用户组成员user数量       |

 
