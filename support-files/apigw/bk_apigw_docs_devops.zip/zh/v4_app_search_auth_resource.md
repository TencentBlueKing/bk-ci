### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/metadata/projects/{projectId}/search_resource
### 资源描述
#### 根据资源名称或 Code 搜索资源
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称         | 参数类型   | 必须  | 参数说明                  |
| ------------ | ------ | --- | --------------------- |
| keyword      | String | √   | 搜索关键词(匹配资源名称或资源Code)  |
| resourceType | String | √   | 资源类型(与权限模型中的资源类型标识一致) |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                      | 说明               |
| ------- | --------------------------------------------------------- | ---------------- |
| default | [ResultListAuthResourceInfo](#ResultListAuthResourceInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?keyword={keyword}&resourceType={resourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "createTime" : "string",
    "createUser" : "",
    "enable" : false,
    "iamGradeManagerId" : "",
    "iamResourceCode" : "",
    "id" : 0,
    "projectCode" : "",
    "relationId" : "",
    "resourceCode" : "",
    "resourceName" : "",
    "resourceType" : "",
    "updateTime" : "string",
    "updateUser" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListAuthResourceInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                        | 必须  | 参数说明 |
| ------- | ------------------------------------------- | --- | ---- |
| data    | List<[AuthResourceInfo](#AuthResourceInfo)> |     | 数据   |
| message | string                                      |     | 错误信息 |
| status  | integer                                     | √   | 状态码  |

#### AuthResourceInfo
##### 资源信息

| 参数名称              | 参数类型    | 必须  | 参数说明 |
| ----------------- | ------- | --- | ---- |
| createTime        | string  | √   |      |
| createUser        | string  | √   |      |
| enable            | boolean | √   |      |
| iamGradeManagerId | string  |     |      |
| iamResourceCode   | string  | √   |      |
| id                | integer |     |      |
| projectCode       | string  | √   |      |
| relationId        | string  | √   |      |
| resourceCode      | string  | √   |      |
| resourceName      | string  | √   |      |
| resourceType      | string  | √   |      |
| updateTime        | string  | √   |      |
| updateUser        | string  | √   |      |

 
