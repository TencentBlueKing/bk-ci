### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/members/{targetMemberId}/exit_check
### 资源描述
#### 检查成员退出/交接权限并推荐交接人
### 输入参数说明
#### Path参数

| 参数名称           | 参数类型   | 必须  | 参数说明                               |
| -------------- | ------ | --- | ---------------------------------- |
| apigwType      | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId      | String | √   | 项目ID(项目英文名)                        |
| targetMemberId | String | √   | 目标成员ID                             |

#### Query参数

| 参数名称           | 参数类型    | 必须  | 参数说明                         |
| -------------- | ------- | --- | ---------------------------- |
| groupIds       | String  |     | 用户组ID列表(多个以逗号分隔),不传则检查退出整个项目 |
| handoverTo     | String  |     | 指定的交接人ID,不传则只做退出检查           |
| recommendLimit | integer |     | 推荐候选交接人数量上限,默认5              |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                | 说明               |
| ------- | --------------------------------------------------- | ---------------- |
| default | [ResultMemberExitCheckVO](#ResultMemberExitCheckVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?groupIds={groupIds}&handoverTo={handoverTo}&recommendLimit={recommendLimit}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "authorizationsToHandover" : {
      "envNode" : 0,
      "pipeline" : 0,
      "repertory" : 0,
      "uniqueManagerGroups" : 0
    },
    "canExitDirectly" : false,
    "departments" : "",
    "handoverToCanReceive" : [ "" ],
    "handoverToCanReceiveAll" : false,
    "handoverToCannotReceive" : [ "" ],
    "handoverToCannotReceiveReasons" : {
      "string" : ""
    },
    "hasDepartmentJoined" : false,
    "needHandover" : false,
    "recommendedCandidates" : [ {
      "canReceive" : [ "" ],
      "canReceiveAll" : false,
      "cannotReceive" : [ "" ],
      "cannotReceiveReasons" : {
        "string" : ""
      },
      "displayName" : "",
      "manager" : false,
      "recommendLevel" : "",
      "requiresValidation" : [ "" ],
      "tags" : [ "" ],
      "userId" : "",
      "validationHints" : {
        "string" : ""
      }
    } ],
    "specifiedHandoverTo" : "",
    "suggestion" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultMemberExitCheckVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                    | 必须  | 参数说明 |
| ------- | --------------------------------------- | --- | ---- |
| data    | [MemberExitCheckVO](#MemberExitCheckVO) |     |      |
| message | string                                  |     | 错误信息 |
| status  | integer                                 | √   | 状态码  |

#### MemberExitCheckVO
##### 成员退出/移出项目检查结果

| 参数名称                           | 参数类型                                                      | 必须  | 参数说明                        |
| ------------------------------ | --------------------------------------------------------- | --- | --------------------------- |
| authorizationsToHandover       | [AuthorizationsToHandoverVO](#AuthorizationsToHandoverVO) |     |                             |
| canExitDirectly                | boolean                                                   | √   | 是否可以直接退出（无需交接）              |
| departments                    | string                                                    |     | 通过组织加入的组织名称                 |
| handoverToCanReceive           | List<string>                                              | √   | 指定交接人可接收的授权类型               |
| handoverToCanReceiveAll        | boolean                                                   | √   | 指定交接人是否可以接收全部授权             |
| handoverToCannotReceive        | List<string>                                              | √   | 指定交接人无法接收的授权类型              |
| handoverToCannotReceiveReasons | Map<String, string>                                       | √   | 指定交接人无法接收的原因                |
| hasDepartmentJoined            | boolean                                                   | √   | 是否通过组织加入项目（退出后可能仍保留组织带来的权限） |
| needHandover                   | boolean                                                   | √   | 是否需要交接                      |
| recommendedCandidates          | List<[HandoverCandidateVO](#HandoverCandidateVO)>         | √   | 推荐的交接人列表（当指定交接人无法接收全部授权时提供） |
| specifiedHandoverTo            | string                                                    |     | 指定的交接人                      |
| suggestion                     | string                                                    |     | 建议信息                        |

#### AuthorizationsToHandoverVO
##### 需要交接的授权统计

| 参数名称                | 参数类型    | 必须  | 参数说明     |
| ------------------- | ------- | --- | -------- |
| envNode             | integer | √   | 环境节点授权数量 |
| pipeline            | integer | √   | 流水线授权数量  |
| repertory           | integer | √   | 代码库授权数量  |
| uniqueManagerGroups | integer | √   | 唯一管理员组数量 |

#### HandoverCandidateVO
##### 交接人候选

| 参数名称                 | 参数类型                | 必须  | 参数说明                                         |
| -------------------- | ------------------- | --- | -------------------------------------------- |
| canReceive           | List<string>        | √   | 可直接接收的授权类型（如uniqueManagerGroup）              |
| canReceiveAll        | boolean             | √   | 是否可接收全部授权（仅当无需验证的授权时为true）                   |
| cannotReceive        | List<string>        | √   | 无法接收的授权类型（已确认无法接收）                           |
| cannotReceiveReasons | Map<String, string> | √   | 无法接收的原因                                      |
| displayName          | string              | √   | 显示名称                                         |
| manager              | boolean             |     | 是否是管理员                                       |
| recommendLevel       | string              | √   | 推荐级别: highly_recommended/recommended/partial |
| requiresValidation   | List<string>        | √   | 需要验证才能确定能否接收的授权类型                            |
| tags                 | List<string>        | √   | 标签                                           |
| userId               | string              | √   | 用户ID                                         |
| validationHints      | Map<String, string> | √   | 验证条件提示                                       |

 
