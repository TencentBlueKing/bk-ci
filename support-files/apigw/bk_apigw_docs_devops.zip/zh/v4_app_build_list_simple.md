### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/build_histories/simple
### 资源描述
#### 获取流水线轻量构建历史
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigwType   |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称           | 参数类型                                                                                                                                                                                                                                                                                                                                                                                               | 必须  | 参数说明                                                    |
| -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --- | ------------------------------------------------------- |
| buildNoEnd     | integer                                                                                                                                                                                                                                                                                                                                                                                            |     | 构件号结束                                                   |
| buildNoStart   | integer                                                                                                                                                                                                                                                                                                                                                                                            |     | 构件号起始                                                   |
| endTimeFrom    | String                                                                                                                                                                                                                                                                                                                                                                                             |     | 结束于-流水线的执行开始时间(格式：yyyy-MM-dd HH:mm:ss)                  |
| endTimeTo      | String                                                                                                                                                                                                                                                                                                                                                                                             |     | 结束于-流水线的执行结束时间(格式：yyyy-MM-dd HH:mm:ss)                  |
| page           | integer                                                                                                                                                                                                                                                                                                                                                                                            | √   | 第几页                                                     |
| pageSize       | integer                                                                                                                                                                                                                                                                                                                                                                                            | √   | 每页条数(默认20, 最大100)                                       |
| pipelineId     | String                                                                                                                                                                                                                                                                                                                                                                                             | √   | 流水线ID                                                   |
| startTimeFrom  | String                                                                                                                                                                                                                                                                                                                                                                                             |     | 开始于-流水线的执行开始时间(格式：yyyy-MM-dd HH:mm:ss)                  |
| startTimeTo    | String                                                                                                                                                                                                                                                                                                                                                                                             |     | 开始于-流水线的执行结束时间(格式：yyyy-MM-dd HH:mm:ss)                  |
| status         | List<ENUM(SUCCEED, FAILED, CANCELED, RUNNING, TERMINATE, REVIEWING, REVIEW_ABORT, REVIEW_PROCESSED, HEARTBEAT_TIMEOUT, PREPARE_ENV, UNEXEC, SKIP, QUALITY_CHECK_FAIL, QUEUE, LOOP_WAITING, CALL_WAITING, TRY_FINALLY, QUEUE_TIMEOUT, EXEC_TIMEOUT, QUEUE_CACHE, RETRY, PAUSE, STAGE_SUCCESS, QUOTA_FAILED, DEPENDENT_WAITING, QUALITY_CHECK_PASS, QUALITY_CHECK_WAIT, TRIGGER_REVIEWING, UNKNOWN)> |     | 状态                                                      |
| updateTimeDesc | boolean                                                                                                                                                                                                                                                                                                                                                                                            |     | 利用updateTime进行排序，true为降序，false为升序，null时以Build number 降序 |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                        | 说明               |
| ------- | ----------------------------------------------------------- | ---------------- |
| default | [ResultPageLightBuildHistory](#ResultPageLightBuildHistory) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?buildNoEnd={buildNoEnd}&buildNoStart={buildNoStart}&endTimeFrom={endTimeFrom}&endTimeTo={endTimeTo}&page={page}&pageSize={pageSize}&pipelineId={pipelineId}&startTimeFrom={startTimeFrom}&startTimeTo={startTimeTo}&status={status}&updateTimeDesc={updateTimeDesc}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "buildNum" : 0,
      "buildParameters" : [ {
        "defaultValue" : "Any 任意类型，参照实际请求或返回",
        "desc" : "",
        "key" : "",
        "value" : "Any 任意类型，参照实际请求或返回",
        "valueType" : "enum"
      } ],
      "endTime" : "",
      "errorInfoList" : [ {
        "atomCode" : "",
        "containerId" : "",
        "errorCode" : 0,
        "errorMsg" : "",
        "errorType" : 0,
        "matrixFlag" : false,
        "stageId" : "",
        "taskId" : "",
        "taskName" : ""
      } ],
      "executeTime" : 0,
      "id" : "",
      "remark" : "",
      "retry" : false,
      "startTime" : "",
      "status" : "",
      "trigger" : "",
      "userId" : ""
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPageLightBuildHistory
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | [PageLightBuildHistory](#PageLightBuildHistory) |     |      |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### PageLightBuildHistory
##### 分页数据包装模型

| 参数名称       | 参数类型                                          | 必须  | 参数说明  |
| ---------- | --------------------------------------------- | --- | ----- |
| count      | integer                                       | √   | 总记录行数 |
| page       | integer                                       | √   | 第几页   |
| pageSize   | integer                                       | √   | 每页多少条 |
| records    | List<[LightBuildHistory](#LightBuildHistory)> | √   | 数据    |
| totalPages | integer                                       | √   | 总共多少页 |

#### LightBuildHistory
##### 轻量历史构建模型

| 参数名称            | 参数类型                                              | 必须  | 参数说明                              |
| --------------- | ------------------------------------------------- | --- | --------------------------------- |
| buildNum        | integer                                           |     | 构建号                               |
| buildParameters | List<[LightBuildParameter](#LightBuildParameter)> |     | 启动参数                              |
| endTime         | string                                            |     | 流水线的执行结束时间(yyyy-MM-dd HH:mm:ss格式) |
| errorInfoList   | List<[ErrorInfo](#ErrorInfo)>                     |     | 流水线任务执行错误                         |
| executeTime     | integer                                           |     | 运行耗时(毫秒，不包括人工审核时间)                |
| id              | string                                            | √   | 构建ID                              |
| remark          | string                                            |     | 备注                                |
| retry           | boolean                                           | √   | 是否重试                              |
| startTime       | string                                            |     | 流水线的执行开始时间(yyyy-MM-dd HH:mm:ss格式) |
| status          | string                                            | √   | 状态                                |
| trigger         | string                                            | √   | 触发条件                              |
| userId          | string                                            | √   | 启动用户                              |

#### LightBuildParameter
##### 轻量构建模型-构建参数

| 参数名称         | 参数类型                                                                                                                                                                                            | 必须  | 参数说明      |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --- | --------- |
| defaultValue | Any                                                                                                                                                                                             |     | 默认值       |
| desc         | string                                                                                                                                                                                          |     | 描述        |
| key          | string                                                                                                                                                                                          | √   | 元素值ID-标识符 |
| value        | Any                                                                                                                                                                                             | √   | 元素值名称-显示用 |
| valueType    | ENUM(string, textarea, enum, date, long, boolean, svn_tag, git_ref, repo_ref, multiple, code_lib, container_type, artifactory, sub_pipeline, custom_file, password, do not storage in database) |     | 元素值类型     |

#### ErrorInfo
##### 插件错误信息

| 参数名称        | 参数类型    | 必须  | 参数说明   |
| ----------- | ------- | --- | ------ |
| atomCode    | string  | √   | 插件编号   |
| containerId | string  |     | 作业ID   |
| errorCode   | integer | √   | 错误码    |
| errorMsg    | string  | √   | 错误信息   |
| errorType   | integer | √   | 错误类型   |
| matrixFlag  | boolean |     | 构建矩阵标识 |
| stageId     | string  |     | 阶段ID   |
| taskId      | string  | √   | 插件ID   |
| taskName    | string  | √   | 插件名称   |

 
