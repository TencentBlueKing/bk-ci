### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/metadata/projects/{projectId}/get_resource_by_name
### 资源描述
#### 根据名称查询资源
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称         | 参数类型   | 必须  | 参数说明                  |
| ------------ | ------ | --- | --------------------- |
| resourceName | String | √   | 资源名称(精确或业务侧约定的名称)     |
| resourceType | String | √   | 资源类型(与权限模型中的资源类型标识一致) |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                              | 说明               |
| ------- | ------------------------------------------------- | ---------------- |
| default | [ResultAuthResourceInfo](#ResultAuthResourceInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?resourceName={resourceName}&resourceType={resourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "createTime" : "string",
    "createUser" : "",
    "enable" : false,
    "iamGradeManagerId" : "",
    "iamResourceCode" : "",
    "id" : 0,
    "projectCode" : "",
    "relationId" : "",
    "resourceCode" : "",
    "resourceName" : "",
    "resourceType" : "",
    "updateTime" : "string",
    "updateUser" : ""
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultAuthResourceInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                  | 必须  | 参数说明 |
| ------- | ------------------------------------- | --- | ---- |
| data    | [AuthResourceInfo](#AuthResourceInfo) |     |      |
| message | string                                |     | 错误信息 |
| status  | integer                               | √   | 状态码  |

#### AuthResourceInfo
##### 资源信息

| 参数名称              | 参数类型    | 必须  | 参数说明 |
| ----------------- | ------- | --- | ---- |
| createTime        | string  | √   |      |
| createUser        | string  | √   |      |
| enable            | boolean | √   |      |
| iamGradeManagerId | string  |     |      |
| iamResourceCode   | string  | √   |      |
| id                | integer |     |      |
| projectCode       | string  | √   |      |
| relationId        | string  | √   |      |
| resourceCode      | string  | √   |      |
| resourceName      | string  | √   |      |
| resourceType      | string  | √   |      |
| updateTime        | string  | √   |      |
| updateUser        | string  | √   |      |

 
