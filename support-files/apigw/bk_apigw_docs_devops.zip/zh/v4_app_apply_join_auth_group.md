### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/member_manage/apply_to_join_group
### 资源描述
#### 申请加入用户组
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称       | 参数类型                                        | 必须   |
| ---------- | ------------------------------------------- | ---- |
| 申请加入用户组请求体 | [AiApplyJoinGroupReq](#AiApplyJoinGroupReq) | true |

#### 响应参数

| HTTP代码  | 参数类型                            | 说明               |
| ------- | ------------------------------- | ---------------- |
| default | [ResultBoolean](#ResultBoolean) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "expiredDays" : 0,
  "groupIds" : [ 0 ],
  "reason" : ""
}
```

### default 返回样例

```Json
{
  "data" : false,
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### AiApplyJoinGroupReq
##### AI申请加入用户组请求体

| 参数名称        | 参数类型          | 必须  | 参数说明          |
| ----------- | ------------- | --- | ------------- |
| expiredDays | integer       | √   | 期望时长(天)，默认180 |
| groupIds    | List<integer> | √   | 用户组ID列表       |
| reason      | string        | √   | 申请理由          |

#### ResultBoolean
##### 数据返回包装模型

| 参数名称    | 参数类型    | 必须  | 参数说明 |
| ------- | ------- | --- | ---- |
| data    | boolean |     | 数据   |
| message | string  |     | 错误信息 |
| status  | integer | √   | 状态码  |

 
