### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/artifactories/metadata/list
### 资源描述
#### 分页查询制品元数据列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |
| projectId | String | √   | 项目ID       |

#### Query参数

| 参数名称            | 参数类型    | 必须  | 参数说明                                       |
| --------------- | ------- | --- | ------------------------------------------ |
| artifactName    | String  |     | 制品名称，如文件名、镜像名                              |
| artifactType    | String  |     | 制品类型：FILE/IMAGE/REPORT/PACKAGE等（不传返回全部类型）  |
| artifactVersion | String  |     | 制品版本，如镜像Tag、包版本                            |
| buildId         | String  |     | 构建ID（可选），不传则不按构建ID过滤                       |
| executeCount    | integer |     | 执行次数（可选），不传则匹配所有执行次数；传 buildId 时不传则取当次构建最新 |
| page            | integer |     | 第几页，默认1                                    |
| pageSize        | integer |     | 每页条数，默认20                                  |
| pipelineId      | String  |     | 流水线ID（可选）                                  |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                              | 说明               |
| ------- | ----------------------------------------------------------------- | ---------------- |
| default | [ResultPagePipelineArtifactInfo](#ResultPagePipelineArtifactInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?artifactName={artifactName}&artifactType={artifactType}&artifactVersion={artifactVersion}&buildId={buildId}&executeCount={executeCount}&page={page}&pageSize={pageSize}&pipelineId={pipelineId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "artifactDigest" : "",
      "artifactName" : "",
      "artifactRepoUrl" : "",
      "artifactSize" : 0,
      "artifactType" : "",
      "artifactUri" : "",
      "artifactVersion" : "",
      "buildId" : "",
      "buildNum" : 0,
      "codeRepoUrl" : "",
      "commitId" : "",
      "containerId" : "",
      "createTime" : "string",
      "creator" : "",
      "executeCount" : 0,
      "extraInfo" : "",
      "id" : 0,
      "modifier" : "",
      "pipelineId" : "",
      "pipelineName" : "",
      "projectId" : "",
      "stageId" : "",
      "taskId" : "",
      "updateTime" : "string"
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPagePipelineArtifactInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                  | 必须  | 参数说明 |
| ------- | ----------------------------------------------------- | --- | ---- |
| data    | [PagePipelineArtifactInfo](#PagePipelineArtifactInfo) |     |      |
| message | string                                                |     | 错误信息 |
| status  | integer                                               | √   | 状态码  |

#### PagePipelineArtifactInfo
##### 分页数据包装模型

| 参数名称       | 参数类型                                                | 必须  | 参数说明  |
| ---------- | --------------------------------------------------- | --- | ----- |
| count      | integer                                             | √   | 总记录行数 |
| page       | integer                                             | √   | 第几页   |
| pageSize   | integer                                             | √   | 每页多少条 |
| records    | List<[PipelineArtifactInfo](#PipelineArtifactInfo)> | √   | 数据    |
| totalPages | integer                                             | √   | 总共多少页 |

#### PipelineArtifactInfo
##### 流水线产出物元数据信息

| 参数名称            | 参数类型    | 必须  | 参数说明                             |
| --------------- | ------- | --- | -------------------------------- |
| artifactDigest  | string  |     | 产出物摘要，如sha256、镜像digest           |
| artifactName    | string  | √   | 产出物名称，如文件名、镜像名                   |
| artifactRepoUrl | string  |     | 产出物仓库地址，如制品库地址、镜像Registry        |
| artifactSize    | integer |     | 产出物大小，单位字节                       |
| artifactType    | string  | √   | 产出物类型：FILE/IMAGE/REPORT/PACKAGE等 |
| artifactUri     | string  |     | 产出物唯一资源标识，如文件路径、镜像完整地址           |
| artifactVersion | string  | √   | 产出物版本，如镜像Tag、包版本                 |
| buildId         | string  | √   | 构建ID                             |
| buildNum        | integer | √   | 构建号                              |
| codeRepoUrl     | string  |     | 代码库地址                            |
| commitId        | string  | √   | 代码提交ID                           |
| containerId     | string  | √   | 构建容器ID                           |
| createTime      | string  | √   | 创建时间                             |
| creator         | string  | √   | 创建人                              |
| executeCount    | integer | √   | 执行次数                             |
| extraInfo       | string  |     | 扩展元数据，JSON格式                     |
| id              | integer | √   | 主键ID                             |
| modifier        | string  | √   | 修改人                              |
| pipelineId      | string  | √   | 流水线ID                            |
| pipelineName    | string  |     | 流水线名称                            |
| projectId       | string  | √   | 蓝盾项目ID                           |
| stageId         | string  | √   | 阶段ID                             |
| taskId          | string  | √   | 任务ID                             |
| updateTime      | string  | √   | 更新时间                             |

 
