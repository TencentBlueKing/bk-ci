### 请求方法/请求路径
#### GET /{apigwType}/v4/atoms/atom_list
### 资源描述
#### 获取所有流水线插件信息
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称                           | 参数类型    | 必须  | 参数说明                                          |
| ------------------------------ | ------- | --- | --------------------------------------------- |
| category                       | String  |     | 插件所属范畴，TRIGGER：触发器类插件 TASK：任务类插件              |
| classifyId                     | String  |     | 插件分类id                                        |
| fitOsFlag                      | boolean |     | 是否适配操作系统标识                                    |
| jobType                        | String  |     | job类型，AGENT： 编译环境，AGENT_LESS：无编译环境            |
| keyword                        | String  |     | 搜索关键字                                         |
| os                             | String  |     | 操作系统（ALL/WINDOWS/LINUX/MACOS）                 |
| page                           | integer |     | 页码                                            |
| pageSize                       | integer |     | 每页数量                                          |
| projectCode                    | String  | √   | 项目编码                                          |
| queryFitAgentBuildLessAtomFlag | boolean |     | 查询支持有编译环境下的无编译环境插件标识                          |
| queryProjectAtomFlag           | boolean |     | 查询项目插件标识                                      |
| recommendFlag                  | boolean |     | 是否推荐                                          |
| serviceScope                   | String  |     | 支持的服务范围（pipeline/quality/all 分别表示流水线/质量红线/全部） |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                      | 说明               |
| ------- | --------------------------------------------------------- | ---------------- |
| default | [ResultAtomRespAtomRespItem](#ResultAtomRespAtomRespItem) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?category={category}&classifyId={classifyId}&fitOsFlag={fitOsFlag}&jobType={jobType}&keyword={keyword}&os={os}&page={page}&pageSize={pageSize}&projectCode={projectCode}&queryFitAgentBuildLessAtomFlag={queryFitAgentBuildLessAtomFlag}&queryProjectAtomFlag={queryProjectAtomFlag}&recommendFlag={recommendFlag}&serviceScope={serviceScope}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "atomCode" : "",
      "atomStatus" : "",
      "atomType" : "",
      "buildLessRunFlag" : false,
      "category" : "",
      "classType" : "",
      "classifyCode" : "",
      "classifyName" : "",
      "createTime" : "",
      "creator" : "",
      "defaultFlag" : false,
      "defaultVersion" : "",
      "description" : "",
      "docsLink" : "",
      "honorInfos" : [ {
        "createTime" : "string",
        "honorId" : "",
        "honorName" : "",
        "honorTitle" : "",
        "mountFlag" : false
      } ],
      "hotFlag" : false,
      "htmlTemplateVersion" : "",
      "icon" : "",
      "indexInfos" : [ {
        "description" : "",
        "hover" : "",
        "iconUrl" : "",
        "indexCode" : "",
        "indexLevelName" : "",
        "indexName" : ""
      } ],
      "installFlag" : false,
      "installed" : false,
      "labelList" : [ {
        "createTime" : 0,
        "id" : "",
        "labelCode" : "",
        "labelName" : "",
        "labelType" : "",
        "serviceScope" : "",
        "updateTime" : 0
      } ],
      "latestFlag" : false,
      "logoUrl" : "",
      "modifier" : "",
      "name" : "",
      "os" : [ "" ],
      "ownerStoreCode" : "",
      "publisher" : "",
      "recentExecuteNum" : 0,
      "recommendFlag" : false,
      "score" : "number",
      "serviceScope" : [ "" ],
      "summary" : "",
      "uninstallFlag" : false,
      "updateTime" : "",
      "version" : "",
      "weight" : 0
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultAtomRespAtomRespItem
##### 数据返回包装模型

| 参数名称    | 参数类型                                          | 必须  | 参数说明 |
| ------- | --------------------------------------------- | --- | ---- |
| data    | [AtomRespAtomRespItem](#AtomRespAtomRespItem) |     |      |
| message | string                                        |     | 错误信息 |
| status  | integer                                       | √   | 状态码  |

#### AtomRespAtomRespItem
##### 流水线-插件信息

| 参数名称       | 参数类型                                | 必须  | 参数说明   |
| ---------- | ----------------------------------- | --- | ------ |
| count      | integer                             | √   | 总记录数   |
| page       | integer                             |     | 当前页码值  |
| pageSize   | integer                             |     | 每页记录大小 |
| records    | List<[AtomRespItem](#AtomRespItem)> |     | 数据集合   |
| totalPages | integer                             | √   | 总页数    |

#### AtomRespItem
##### 流水线-插件信息

| 参数名称                | 参数类型                                    | 必须  | 参数说明                                                                                                                                                                               |
| ------------------- | --------------------------------------- | --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| atomCode            | string                                  | √   | 插件代码                                                                                                                                                                               |
| atomStatus          | string                                  | √   | 插件状态，INIT：初始化|COMMITTING：提交中|BUILDING：构建中|BUILD_FAIL：构建失败|TESTING：测试中|AUDITING：审核中|AUDIT_REJECT：审核驳回|RELEASED：已发布|GROUNDING_SUSPENSION：上架中止|UNDERCARRIAGING：下架中|UNDERCARRIAGED：已下架 |
| atomType            | string                                  | √   | 插件类型，SELF_DEVELOPED：自研 THIRD_PARTY：第三方开发                                                                                                                                           |
| buildLessRunFlag    | boolean                                 |     | 无构建环境插件是否可以在有构建环境运行标识， TRUE：可以 FALSE：不可以                                                                                                                                           |
| category            | string                                  | √   | 插件所属范畴，TRIGGER：触发器类插件 TASK：任务类插件                                                                                                                                                   |
| classType           | string                                  | √   | 插件大类（插件市场发布的插件分为有marketBuild：构建环境和marketBuildLess：无构建环境）                                                                                                                           |
| classifyCode        | string                                  | √   | 所属分类编码                                                                                                                                                                             |
| classifyName        | string                                  | √   | 所属分类名称                                                                                                                                                                             |
| createTime          | string                                  | √   | 创建时间                                                                                                                                                                               |
| creator             | string                                  | √   | 创建人                                                                                                                                                                                |
| defaultFlag         | boolean                                 | √   | 是否为默认插件（默认插件默认所有项目可见）true：默认插件 false：普通插件                                                                                                                                          |
| defaultVersion      | string                                  | √   | 插件默认版本号                                                                                                                                                                            |
| description         | string                                  |     | 插件描述                                                                                                                                                                               |
| docsLink            | string                                  |     | 插件说明文档链接                                                                                                                                                                           |
| honorInfos          | List<[HonorInfo](#HonorInfo)>           |     | 荣誉信息                                                                                                                                                                               |
| hotFlag             | boolean                                 |     | hotFlag                                                                                                                                                                            |
| htmlTemplateVersion | string                                  | √   | 前端渲染模板版本（1.0代表历史存量插件渲染模板版本）                                                                                                                                                        |
| icon                | string                                  |     | 插件图标                                                                                                                                                                               |
| indexInfos          | List<[StoreIndexInfo](#StoreIndexInfo)> |     | 指标信息列表                                                                                                                                                                             |
| installFlag         | boolean                                 |     | 是否有权限安装标识                                                                                                                                                                          |
| installed           | boolean                                 |     | 是否已安装                                                                                                                                                                              |
| labelList           | List<[Label](#Label)>                   |     | 标签列表                                                                                                                                                                               |
| latestFlag          | boolean                                 | √   | 是否为最新版本插件 true：最新 false：非最新                                                                                                                                                        |
| logoUrl             | string                                  |     | 插件logo                                                                                                                                                                             |
| modifier            | string                                  | √   | 修改人                                                                                                                                                                                |
| name                | string                                  | √   | 插件名称                                                                                                                                                                               |
| os                  | List<string>                            | √   | 支持的操作系统                                                                                                                                                                            |
| ownerStoreCode      | string                                  |     | 归属应用标识                                                                                                                                                                             |
| publisher           | string                                  |     | 发布者                                                                                                                                                                                |
| recentExecuteNum    | integer                                 |     | 最近执行次数                                                                                                                                                                             |
| recommendFlag       | boolean                                 |     | 是否推荐标识 true：推荐，false：不推荐                                                                                                                                                           |
| score               | number                                  |     | 评分                                                                                                                                                                                 |
| serviceScope        | List<string>                            | √   | 服务范围                                                                                                                                                                               |
| summary             | string                                  |     | 插件简介                                                                                                                                                                               |
| uninstallFlag       | boolean                                 |     | 是否能卸载标识                                                                                                                                                                            |
| updateTime          | string                                  | √   | 修改时间                                                                                                                                                                               |
| version             | string                                  | √   | 插件版本                                                                                                                                                                               |
| weight              | integer                                 |     | 权重（数值越大代表权重越高）                                                                                                                                                                     |

#### HonorInfo
##### 荣誉信息

| 参数名称       | 参数类型    | 必须  | 参数说明 |
| ---------- | ------- | --- | ---- |
| createTime | string  | √   | 创建时间 |
| honorId    | string  | √   | 荣誉ID |
| honorName  | string  | √   | 荣誉名称 |
| honorTitle | string  | √   | 荣誉头衔 |
| mountFlag  | boolean | √   | 是否佩戴 |

#### StoreIndexInfo
##### 研发商店指标信息

| 参数名称           | 参数类型   | 必须  | 参数说明   |
| -------------- | ------ | --- | ------ |
| description    | string | √   | 指标描述   |
| hover          | string | √   | 指标状态显示 |
| iconUrl        | string | √   | 图标地址   |
| indexCode      | string | √   | 指标代码   |
| indexLevelName | string | √   | 等级名称   |
| indexName      | string | √   | 指标名称   |

#### Label
##### 标签信息

| 参数名称         | 参数类型    | 必须  | 参数说明                                           |
| ------------ | ------- | --- | ---------------------------------------------- |
| createTime   | integer | √   | 创建日期                                           |
| id           | string  | √   | 标签ID                                           |
| labelCode    | string  | √   | 标签代码                                           |
| labelName    | string  | √   | 标签名称                                           |
| labelType    | string  | √   | 类别 ATOM:插件 TEMPLATE:模板 IMAGE:镜像 IDE_ATOM:IDE插件 |
| serviceScope | string  |     | 服务范围                                           |
| updateTime   | integer | √   | 更新日期                                           |

 
