### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/members/group_count
### 资源描述
#### 获取成员用户组数量
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数

| 参数名称                | 参数类型   | 必须  | 参数说明               |
| ------------------- | ------ | --- | ------------------ |
| memberId            | String | √   | 目标成员ID(用户名等)       |
| relatedResourceCode | String |     | 关联资源Code           |
| relatedResourceType | String |     | 关联资源类型(按资源维度统计时传入) |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                              | 说明               |
| ------- | ----------------------------------------------------------------- | ---------------- |
| default | [ResultListResourceType2CountVo](#ResultListResourceType2CountVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?memberId={memberId}&relatedResourceCode={relatedResourceCode}&relatedResourceType={relatedResourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "count" : 0,
    "resourceType" : "",
    "resourceTypeName" : "",
    "type" : "enum"
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListResourceType2CountVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                | 必须  | 参数说明 |
| ------- | --------------------------------------------------- | --- | ---- |
| data    | List<[ResourceType2CountVo](#ResourceType2CountVo)> |     | 数据   |
| message | string                                              |     | 错误信息 |
| status  | integer                                             | √   | 状态码  |

#### ResourceType2CountVo
##### 用户有权限的用户组数量

| 参数名称             | 参数类型                       | 必须  | 参数说明  |
| ---------------- | -------------------------- | --- | ----- |
| count            | integer                    | √   | 数量    |
| resourceType     | string                     | √   | 资源类型  |
| resourceTypeName | string                     | √   | 资源类型名 |
| type             | ENUM(GROUP, AUTHORIZATION) | √   | 类型    |

 
