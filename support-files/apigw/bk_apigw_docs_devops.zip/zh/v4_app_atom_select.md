### 请求方法/请求路径
#### GET /{apigwType}/v4/atoms/atom_select
### 资源描述
#### 插件选型检索：按检索词从全商店召回有运行时契约的插件，返回可用状态与不适用场景
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明       |
| --------- | ------ | --- | ---------- |
| apigwType | String | √   | apigw Type |

#### Query参数

| 参数名称        | 参数类型    | 必须  | 参数说明                                                      |
| ----------- | ------- | --- | --------------------------------------------------------- |
| category    | String  |     | 插件所属范畴，TRIGGER：触发器类插件 TASK：任务类插件                          |
| jobType     | String  |     | job类型：AGENT（编译环境）/ AGENT_LESS（无编译环境）                      |
| keywords    | String  | √   | 检索词，逗号、顿号或空白分隔，最多 8 个，例如 COS,对象存储,上传,upload；等于插件代码或插件名时置顶 |
| limit       | integer |     | 返回条数，1～20，默认 10                                           |
| os          | String  |     | 操作系统（ALL/WINDOWS/LINUX/MACOS）                             |
| projectCode | String  | √   | 项目编码                                                      |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                          | 说明               |
| ------- | --------------------------------------------- | ---------------- |
| default | [ResultAtomSelectResp](#ResultAtomSelectResp) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?category={category}&jobType={jobType}&keywords={keywords}&limit={limit}&os={os}&projectCode={projectCode}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "contractCount" : 0,
    "items" : [ {
      "atomCode" : "",
      "availability" : "enum",
      "coverage" : "",
      "defaultVersion" : "",
      "hasContract" : false,
      "matched" : [ "" ],
      "name" : "",
      "notFor" : [ "" ],
      "prerequisites" : [ "" ],
      "recentExecuteNum" : 0,
      "selectionSummary" : "",
      "stale" : false
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultAtomSelectResp
##### 数据返回包装模型

| 参数名称    | 参数类型                              | 必须  | 参数说明 |
| ------- | --------------------------------- | --- | ---- |
| data    | [AtomSelectResp](#AtomSelectResp) |     |      |
| message | string                            |     | 错误信息 |
| status  | integer                           | √   | 状态码  |

#### AtomSelectResp
##### 插件选型检索结果

| 参数名称          | 参数类型                                    | 必须  | 参数说明                |
| ------------- | --------------------------------------- | --- | ------------------- |
| contractCount | integer                                 | √   | 参与召回的契约总数，偏低时结果可能不全 |
| items         | List<[AtomSelectItem](#AtomSelectItem)> | √   | 候选插件，按相关度排序         |

#### AtomSelectItem
##### 插件选型候选

| 参数名称             | 参数类型                                 | 必须  | 参数说明                |
| ---------------- | ------------------------------------ | --- | ------------------- |
| atomCode         | string                               | √   | 插件标识                |
| availability     | ENUM(READY, INSTALLABLE, NEED_APPLY) | √   | 在目标项目中的可用状态         |
| coverage         | string                               |     | 契约覆盖程度              |
| defaultVersion   | string                               | √   | YAML 中引用的默认版本，如 5.* |
| hasContract      | boolean                              | √   | 是否有运行时契约            |
| matched          | List<string>                         | √   | 命中的检索词              |
| name             | string                               | √   | 插件名称                |
| notFor           | List<string>                         | √   | 不适用场景               |
| prerequisites    | List<string>                         | √   | 使用前提                |
| recentExecuteNum | integer                              |     | 近期执行次数              |
| selectionSummary | string                               |     | 选型用一句话说明，没有契约时为插件简介 |
| stale            | boolean                              |     | 契约是否因新版本过期          |

 
