### 请求方法/请求路径
#### GET /{apigwType}/v4/store/components/projects/{projectCode}/types/{storeType}/component/list
### 资源描述
#### 根据条件查询项目下组件列表
### 输入参数说明
#### Path参数

| 参数名称        | 参数类型   | 必须  | 参数说明       |
| ----------- | ------ | --- | ---------- |
| apigwType   | String | √   | apigw Type |
| projectCode | String | √   | 项目代码       |
| storeType   | String | √   | 组件类型       |

#### Query参数

| 参数名称          | 参数类型                                                                     | 必须  | 参数说明                       |
| ------------- | ------------------------------------------------------------------------ | --- | -------------------------- |
| categoryId    | String                                                                   |     | 范畴ID                       |
| classifyId    | String                                                                   |     | 分类ID                       |
| installed     | boolean                                                                  |     | 是否已在该项目安装 true：是，false：否   |
| instanceId    | String                                                                   |     | 实例ID                       |
| keyword       | String                                                                   |     | 搜索关键字                      |
| labelId       | String                                                                   |     | 标签ID                       |
| page          | integer                                                                  | √   | 页码                         |
| pageSize      | integer                                                                  | √   | 每页数量                       |
| queryTestFlag | boolean                                                                  |     | 是否查测试中版本 true：是，false：否    |
| rdType        | ENUM(SELF_DEVELOPED, THIRD_PARTY)                                        |     | 研发来源类型                     |
| recommendFlag | boolean                                                                  |     | 是否推荐标识 true：推荐，false：不推荐   |
| score         | integer                                                                  |     | 评分                         |
| sortType      | ENUM(NAME, CREATE_TIME, UPDATE_TIME, PUBLISHER, DOWNLOAD_COUNT, UPGRADE) |     | 排序                         |
| updateFlag    | boolean                                                                  |     | 是否需要更新标识 true：需要，false：不需要 |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                          | 说明               |
| ------- | --------------------------------------------- | ---------------- |
| default | [ResultPageMarketItem](#ResultPageMarketItem) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?categoryId={categoryId}&classifyId={classifyId}&installed={installed}&instanceId={instanceId}&keyword={keyword}&labelId={labelId}&page={page}&pageSize={pageSize}&queryTestFlag={queryTestFlag}&rdType={rdType}&recommendFlag={recommendFlag}&score={score}&sortType={sortType}&updateFlag={updateFlag}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "page" : 0,
    "pageSize" : 0,
    "records" : [ {
      "buildLessRunFlag" : false,
      "category" : "",
      "classifyCode" : "",
      "code" : "",
      "dailyStatisticList" : [ {
        "dailyActiveDuration" : "number",
        "dailyDownloads" : 0,
        "dailyFailDetail" : {
          "string" : "Any 任意类型，参照实际请求或返回"
        },
        "dailyFailNum" : 0,
        "dailyFailRate" : "number",
        "dailySuccessNum" : 0,
        "dailySuccessRate" : "number",
        "statisticsTime" : "",
        "totalDownloads" : 0
      } ],
      "docsLink" : "",
      "downloads" : 0,
      "extData" : {
        "string" : "Any 任意类型，参照实际请求或返回"
      },
      "flag" : false,
      "honorInfos" : [ {
        "createTime" : "string",
        "honorId" : "",
        "honorName" : "",
        "honorTitle" : "",
        "mountFlag" : false
      } ],
      "hotFlag" : false,
      "id" : "",
      "indexInfos" : [ {
        "description" : "",
        "hover" : "",
        "iconUrl" : "",
        "indexCode" : "",
        "indexLevelName" : "",
        "indexName" : ""
      } ],
      "installed" : false,
      "logoUrl" : "",
      "modifier" : "",
      "name" : "",
      "os" : [ "" ],
      "ownerStoreCode" : "",
      "ownerStoreName" : "",
      "publicFlag" : false,
      "publisher" : "",
      "rdType" : "",
      "recentExecuteNum" : 0,
      "recommendFlag" : false,
      "score" : "number",
      "srcProjectId" : "",
      "status" : "",
      "summary" : "",
      "type" : "",
      "updateFlag" : false,
      "updateTime" : "",
      "version" : "",
      "yamlFlag" : false
    } ],
    "totalPages" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultPageMarketItem
##### 数据返回包装模型

| 参数名称    | 参数类型                              | 必须  | 参数说明 |
| ------- | --------------------------------- | --- | ---- |
| data    | [PageMarketItem](#PageMarketItem) |     |      |
| message | string                            |     | 错误信息 |
| status  | integer                           | √   | 状态码  |

#### PageMarketItem
##### 分页数据包装模型

| 参数名称       | 参数类型                            | 必须  | 参数说明  |
| ---------- | ------------------------------- | --- | ----- |
| count      | integer                         | √   | 总记录行数 |
| page       | integer                         | √   | 第几页   |
| pageSize   | integer                         | √   | 每页多少条 |
| records    | List<[MarketItem](#MarketItem)> | √   | 数据    |
| totalPages | integer                         | √   | 总共多少页 |

#### MarketItem
##### 研发商店组件信息

| 参数名称               | 参数类型                                              | 必须  | 参数说明                                              |
| ------------------ | ------------------------------------------------- | --- | ------------------------------------------------- |
| buildLessRunFlag   | boolean                                           |     | 无编译环境组件是否可以在编译环境下执行标识                             |
| category           | string                                            |     | 所属范畴，多个范畴标识用逗号分隔                                  |
| classifyCode       | string                                            |     | 分类                                                |
| code               | string                                            | √   | 组件标识                                              |
| dailyStatisticList | List<[StoreDailyStatistic](#StoreDailyStatistic)> |     | 每日统计信息列表                                          |
| docsLink           | string                                            |     | 帮助文档                                              |
| downloads          | integer                                           |     | 下载量                                               |
| extData            | Map<String, Any>                                  |     | 扩展字段集合(列表精简版：组件级特性如installPath/os + 版本级urlScheme) |
| flag               | boolean                                           | √   | 是否有权限安装标识                                         |
| honorInfos         | List<[HonorInfo](#HonorInfo)>                     |     | 荣誉信息列表                                            |
| hotFlag            | boolean                                           |     | 是否为受欢迎组件                                          |
| id                 | string                                            | √   | ID                                                |
| indexInfos         | List<[StoreIndexInfo](#StoreIndexInfo)>           |     | 指标信息列表                                            |
| installed          | boolean                                           |     | 是否已在该项目安装 true：是，false：否                          |
| logoUrl            | string                                            |     | logo链接                                            |
| modifier           | string                                            | √   | 修改人                                               |
| name               | string                                            | √   | 名称                                                |
| os                 | List<string>                                      |     | 支持的操作系统                                           |
| ownerStoreCode     | string                                            |     | 宿主应用标识                                            |
| ownerStoreName     | string                                            |     | 宿主应用名                                             |
| publicFlag         | boolean                                           | √   | 是否公共标识                                            |
| publisher          | string                                            | √   | 发布者                                               |
| rdType             | string                                            |     | 研发来源类型                                            |
| recentExecuteNum   | integer                                           |     | 最近执行次数                                            |
| recommendFlag      | boolean                                           |     | 是否推荐标识 true：推荐，false：不推荐                          |
| score              | number                                            |     | 评分                                                |
| srcProjectId       | string                                            |     | 组件来源项目ID                                          |
| status             | string                                            | √   | 状态                                                |
| summary            | string                                            |     | 简介                                                |
| type               | string                                            | √   | 组件类型                                              |
| updateFlag         | boolean                                           |     | 是否需要更新                                            |
| updateTime         | string                                            | √   | 修改时间                                              |
| version            | string                                            | √   | 版本号                                               |
| yamlFlag           | boolean                                           |     | yaml可用标识 true：是，false：否                           |

#### StoreDailyStatistic
##### 每日统计信息

| 参数名称                | 参数类型             | 必须  | 参数说明                       |
| ------------------- | ---------------- | --- | -------------------------- |
| dailyActiveDuration | number           |     | 每日活跃时长，单位：小时               |
| dailyDownloads      | integer          | √   | 每日下载量                      |
| dailyFailDetail     | Map<String, Any> |     | 每日执行失败详情                   |
| dailyFailNum        | integer          | √   | 每日执行失败数                    |
| dailyFailRate       | number           |     | 每日执行失败率                    |
| dailySuccessNum     | integer          | √   | 每日执行成功数                    |
| dailySuccessRate    | number           |     | 每日执行成功率                    |
| statisticsTime      | string           | √   | 统计时间，格式yyyy-MM-dd HH:mm:ss |
| totalDownloads      | integer          | √   | 总下载量                       |

#### HonorInfo
##### 荣誉信息

| 参数名称       | 参数类型    | 必须  | 参数说明 |
| ---------- | ------- | --- | ---- |
| createTime | string  | √   | 创建时间 |
| honorId    | string  | √   | 荣誉ID |
| honorName  | string  | √   | 荣誉名称 |
| honorTitle | string  | √   | 荣誉头衔 |
| mountFlag  | boolean | √   | 是否佩戴 |

#### StoreIndexInfo
##### 研发商店指标信息

| 参数名称           | 参数类型   | 必须  | 参数说明   |
| -------------- | ------ | --- | ------ |
| description    | string | √   | 指标描述   |
| hover          | string | √   | 指标状态显示 |
| iconUrl        | string | √   | 图标地址   |
| indexCode      | string | √   | 指标代码   |
| indexLevelName | string | √   | 等级名称   |
| indexName      | string | √   | 指标名称   |

 
