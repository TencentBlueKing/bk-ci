### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/members/exits_project_check
### 资源描述
#### 用户主动退出项目检查
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                                | 说明               |
| ------- | ------------------------------------------------------------------- | ---------------- |
| default | [ResultMemberExitsProjectCheckVo](#ResultMemberExitsProjectCheckVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "departmentJoinedCount" : 0,
    "departments" : "",
    "envNodeAuthorizationCount" : 0,
    "managers" : [ "" ],
    "pipelineAuthorizationCount" : 0,
    "repositoryAuthorizationCount" : 0,
    "uniqueManagerCount" : 0
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultMemberExitsProjectCheckVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                                    | 必须  | 参数说明 |
| ------- | ------------------------------------------------------- | --- | ---- |
| data    | [MemberExitsProjectCheckVo](#MemberExitsProjectCheckVo) |     |      |
| message | string                                                  |     | 错误信息 |
| status  | integer                                                 | √   | 状态码  |

#### MemberExitsProjectCheckVo
##### 成员退出项目检查返回体

| 参数名称                         | 参数类型         | 必须  | 参数说明      |
| ---------------------------- | ------------ | --- | --------- |
| departmentJoinedCount        | integer      |     | 组织加入的数量   |
| departments                  | string       |     | 组织        |
| envNodeAuthorizationCount    | integer      |     | 环境节点授权数量  |
| managers                     | List<string> |     | 项目管理员     |
| pipelineAuthorizationCount   | integer      |     | 流水线授权数量   |
| repositoryAuthorizationCount | integer      |     | 代码库授权数量   |
| uniqueManagerCount           | integer      |     | 唯一管理员组的数量 |

 
