### 请求方法/请求路径
#### POST /{apigwType}/v4/auth/project/{projectId}/member_manage/list_groups
### 资源描述
#### 查询用户组列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |
| projectId | String | √   | 项目ID(项目英文名)                        |

#### Query参数
###### 无此参数
#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数

| 参数名称                       | 参数类型                                                          | 必须   |
| -------------------------- | ------------------------------------------------------------- | ---- |
| 用户组查询条件(含IAM用户组ID、资源维度等筛选) | [IamGroupIdsQueryConditionDTO](#IamGroupIdsQueryConditionDTO) | true |

#### 响应参数

| HTTP代码  | 参数类型                                                              | 说明               |
| ------- | ----------------------------------------------------------------- | ---------------- |
| default | [ResultSQLPageAuthResourceGroup](#ResultSQLPageAuthResourceGroup) | default response |

### Curl 请求样例

```Json
curl -X POST '[请替换为上方API地址栏请求地址]' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### POST 请求样例

```Json
{
  "action" : "",
  "groupName" : "",
  "iamGroupIds" : [ 0 ],
  "page" : 0,
  "pageSize" : 0,
  "projectCode" : "",
  "queryByGroupName" : false,
  "queryByGroupPermissions" : false,
  "relatedResourceCode" : "",
  "relatedResourceType" : "",
  "uniqueManagerGroupsQueryFlag" : false
}
```

### default 返回样例

```Json
{
  "data" : {
    "count" : 0,
    "records" : [ {
      "applyDisable" : false,
      "createTime" : "string",
      "defaultGroup" : false,
      "description" : "",
      "groupCode" : "",
      "groupName" : "",
      "iamResourceCode" : "",
      "iamTemplateId" : 0,
      "id" : 0,
      "projectCode" : "",
      "relationId" : 0,
      "resourceCode" : "",
      "resourceName" : "",
      "resourceType" : "",
      "updateTime" : "string"
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### IamGroupIdsQueryConditionDTO
##### 用户组ID查询业务实体

| 参数名称                         | 参数类型          | 必须  | 参数说明                                  |
| ---------------------------- | ------------- | --- | ------------------------------------- |
| action                       | string        |     | 操作                                    |
| groupName                    | string        |     | 用户组名称                                 |
| iamGroupIds                  | List<integer> |     | 组ID列表                                 |
| page                         | integer       |     | 页码，从 1 开始；与 pageSize 同时不传则不分页，返回全部匹配组 |
| pageSize                     | integer       |     | 每页条数，最大 200；与 page 同时不传则不分页，返回全部匹配组   |
| projectCode                  | string        | √   | 项目ID                                  |
| queryByGroupName             | boolean       |     |                                       |
| queryByGroupPermissions      | boolean       |     |                                       |
| relatedResourceCode          | string        |     | 资源ID                                  |
| relatedResourceType          | string        |     | 资源类型                                  |
| uniqueManagerGroupsQueryFlag | boolean       |     | 唯一管理员组查询标识                            |

#### ResultSQLPageAuthResourceGroup
##### 数据返回包装模型

| 参数名称    | 参数类型                                                  | 必须  | 参数说明 |
| ------- | ----------------------------------------------------- | --- | ---- |
| data    | [SQLPageAuthResourceGroup](#SQLPageAuthResourceGroup) |     |      |
| message | string                                                |     | 错误信息 |
| status  | integer                                               | √   | 状态码  |

#### SQLPageAuthResourceGroup
##### 数据

| 参数名称    | 参数类型                                          | 必须  | 参数说明 |
| ------- | --------------------------------------------- | --- | ---- |
| count   | integer                                       |     |      |
| records | List<[AuthResourceGroup](#AuthResourceGroup)> |     |      |

#### AuthResourceGroup
##### 资源用户组信息

| 参数名称            | 参数类型    | 必须  | 参数说明                             |
| --------------- | ------- | --- | -------------------------------- |
| applyDisable    | boolean |     | 是否禁止申请                           |
| createTime      | string  |     | 创建时间                             |
| defaultGroup    | boolean | √   | 是否是默认组                           |
| description     | string  |     | 用户组描述                            |
| groupCode       | string  | √   | 组编码, @See DefaultGroupType       |
| groupName       | string  | √   | 用户组名, @See DefaultGroupType      |
| iamResourceCode | string  | √   | IAM资源ID                          |
| iamTemplateId   | integer |     | IAM人员模板ID                        |
| id              | integer |     |                                  |
| projectCode     | string  | √   | 项目ID                             |
| relationId      | integer | √   | IAM 用户组ID, @See DefaultGroupType |
| resourceCode    | string  | √   | 资源ID                             |
| resourceName    | string  | √   | 资源名                              |
| resourceType    | string  | √   | 资源类型                             |
| updateTime      | string  |     | 更新时间                             |

 
