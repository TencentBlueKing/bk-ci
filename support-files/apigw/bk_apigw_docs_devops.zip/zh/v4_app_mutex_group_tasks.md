### 请求方法/请求路径
#### GET /{apigwType}/v4/projects/{projectId}/mutex_group_tasks
### 资源描述
#### 查询互斥组当前任务列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明        |
| --------- | ------ | --- | ----------- |
| apigwType | String | √   | apigw Type  |
| projectId | String | √   | 项目ID(项目英文名) |

#### Query参数

| 参数名称           | 参数类型   | 必须  | 参数说明                |
| -------------- | ------ | --- | ------------------- |
| mutexGroupName | String | √   | 互斥组名称（变量已替换后的运行时名称） |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                          | 说明               |
| ------- | ------------------------------------------------------------- | ---------------- |
| default | [ResultListMutexGroupTaskInfo](#ResultListMutexGroupTaskInfo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?mutexGroupName={mutexGroupName}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "buildId" : "",
    "containerId" : "",
    "jobId" : "",
    "jobName" : "",
    "lockHolder" : false,
    "mutexGroupName" : "",
    "pipelineId" : "",
    "pipelineName" : "",
    "status" : "enum"
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListMutexGroupTaskInfo
##### 数据返回包装模型

| 参数名称    | 参数类型                                            | 必须  | 参数说明 |
| ------- | ----------------------------------------------- | --- | ---- |
| data    | List<[MutexGroupTaskInfo](#MutexGroupTaskInfo)> |     | 数据   |
| message | string                                          |     | 错误信息 |
| status  | integer                                         | √   | 状态码  |

#### MutexGroupTaskInfo
##### 互斥组任务信息

| 参数名称           | 参数类型                                                                                                                                                                                                                                                                                                                                                                                         | 必须  | 参数说明       |
| -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --- | ---------- |
| buildId        | string                                                                                                                                                                                                                                                                                                                                                                                       | √   | 构建ID       |
| containerId    | string                                                                                                                                                                                                                                                                                                                                                                                       |     | 引擎Job实例ID  |
| jobId          | string                                                                                                                                                                                                                                                                                                                                                                                       |     | 用户配置的Job标识 |
| jobName        | string                                                                                                                                                                                                                                                                                                                                                                                       |     | Job名称      |
| lockHolder     | boolean                                                                                                                                                                                                                                                                                                                                                                                      | √   | 是否当前锁持有者   |
| mutexGroupName | string                                                                                                                                                                                                                                                                                                                                                                                       | √   | 互斥组名称      |
| pipelineId     | string                                                                                                                                                                                                                                                                                                                                                                                       |     | 流水线ID      |
| pipelineName   | string                                                                                                                                                                                                                                                                                                                                                                                       |     | 流水线名称      |
| status         | ENUM(SUCCEED, FAILED, CANCELED, RUNNING, TERMINATE, REVIEWING, REVIEW_ABORT, REVIEW_PROCESSED, HEARTBEAT_TIMEOUT, PREPARE_ENV, UNEXEC, SKIP, QUALITY_CHECK_FAIL, QUEUE, LOOP_WAITING, CALL_WAITING, TRY_FINALLY, QUEUE_TIMEOUT, EXEC_TIMEOUT, QUEUE_CACHE, RETRY, PAUSE, STAGE_SUCCESS, QUOTA_FAILED, DEPENDENT_WAITING, QUALITY_CHECK_PASS, QUALITY_CHECK_WAIT, TRIGGER_REVIEWING, UNKNOWN) | √   | 构建状态       |

 
