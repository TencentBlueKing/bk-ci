### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/metadata/list_actions
### 资源描述
#### 获取资源类型对应的操作列表
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |

#### Query参数

| 参数名称         | 参数类型   | 必须  | 参数说明                  |
| ------------ | ------ | --- | --------------------- |
| resourceType | String | √   | 资源类型(与权限模型中的资源类型标识一致) |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                              | 说明               |
| ------- | ------------------------------------------------- | ---------------- |
| default | [ResultListActionInfoVo](#ResultListActionInfoVo) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?resourceType={resourceType}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : [ {
    "action" : "",
    "actionName" : "",
    "relatedResourceType" : "",
    "resourceType" : ""
  } ],
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultListActionInfoVo
##### 数据返回包装模型

| 参数名称    | 参数类型                                | 必须  | 参数说明 |
| ------- | ----------------------------------- | --- | ---- |
| data    | List<[ActionInfoVo](#ActionInfoVo)> |     | 数据   |
| message | string                              |     | 错误信息 |
| status  | integer                             | √   | 状态码  |

#### ActionInfoVo
##### 操作实体

| 参数名称                | 参数类型   | 必须  | 参数说明       |
| ------------------- | ------ | --- | ---------- |
| action              | string | √   | action     |
| actionName          | string | √   | 动作名        |
| relatedResourceType | string | √   | IAM-关联资源类型 |
| resourceType        | string | √   | 蓝盾-关联资源类型  |

 
