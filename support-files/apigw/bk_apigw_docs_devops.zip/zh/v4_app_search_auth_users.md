### 请求方法/请求路径
#### GET /{apigwType}/v4/auth/project/{projectId}/member_manage/users/search
### 资源描述
#### 根据关键词搜索用户
### 输入参数说明
#### Path参数

| 参数名称      | 参数类型   | 必须  | 参数说明                               |
| --------- | ------ | --- | ---------------------------------- |
| apigwType | String | √   | 网关类型,取值为apigw-user、apigw-app或apigw |

#### Query参数

| 参数名称      | 参数类型    | 必须  | 参数说明                        |
| --------- | ------- | --- | --------------------------- |
| keyword   | String  | √   | 搜索关键词(用户名等)                 |
| limit     | integer |     | 返回条数上限,默认10                 |
| projectId | String  |     | 限定搜索范围的项目ID(项目英文名),不传则不限定项目 |

#### Header参数

| 参数名称         | 参数类型   | 必须  | 参数说明             |
| ------------ | ------ | --- | ---------------- |
| Content-Type | string | √   | application/json |
| X-DEVOPS-UID | string | √   | 用户名              |

#### Body参数
###### 无此参数
#### 响应参数

| HTTP代码  | 参数类型                                                  | 说明               |
| ------- | ----------------------------------------------------- | ---------------- |
| default | [ResultUserSearchResultVO](#ResultUserSearchResultVO) | default response |

### Curl 请求样例

```Json
curl -X GET '[请替换为上方API地址栏请求地址]?keyword={keyword}&limit={limit}&projectId={projectId}' \
-H 'Content-Type: application/json' \
-H 'X-DEVOPS-UID: 用户名' 
```

### default 返回样例

```Json
{
  "data" : {
    "exactMatch" : false,
    "keyword" : "",
    "totalCount" : 0,
    "users" : [ {
      "department" : "",
      "displayName" : "",
      "email" : "",
      "projectMember" : false,
      "userId" : ""
    } ]
  },
  "message" : "",
  "status" : 0
}
```

### 相关模型数据
#### ResultUserSearchResultVO
##### 数据返回包装模型

| 参数名称    | 参数类型                                      | 必须  | 参数说明 |
| ------- | ----------------------------------------- | --- | ---- |
| data    | [UserSearchResultVO](#UserSearchResultVO) |     |      |
| message | string                                    |     | 错误信息 |
| status  | integer                                   | √   | 状态码  |

#### UserSearchResultVO
##### 用户搜索结果

| 参数名称       | 参数类型                            | 必须  | 参数说明     |
| ---------- | ------------------------------- | --- | -------- |
| exactMatch | boolean                         | √   | 是否精确匹配   |
| keyword    | string                          | √   | 搜索关键词    |
| totalCount | integer                         | √   | 总数       |
| users      | List<[UserInfoVO](#UserInfoVO)> | √   | 搜索到的用户列表 |

#### UserInfoVO
##### 用户信息

| 参数名称          | 参数类型    | 必须  | 参数说明    |
| ------------- | ------- | --- | ------- |
| department    | string  |     | 部门      |
| displayName   | string  | √   | 显示名称    |
| email         | string  |     | 邮箱      |
| projectMember | boolean |     | 是否是项目成员 |
| userId        | string  | √   | 用户ID    |

 
